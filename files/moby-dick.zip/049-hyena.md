### Chapter 49.

# The Hyena.

There are certain queer times and occasions in this strange mixed affair we
call life when a man takes this whole universe for a vast practical joke,
though the wit thereof he but dimly discerns, and more than suspects that the
joke is at nobody’s expense but his own. However, nothing dispirits, and
nothing seems worth while disputing. He bolts down all events, all creeds, and
beliefs, and persuasions, all hard things visible and invisible, never mind how
knobby; as an ostrich of potent digestion gobbles down bullets and gun flints.
And as for small difficulties and worryings, prospects of sudden disaster,
peril of life and limb; all these, and death itself, seem to him only sly,
good-natured hits, and jolly punches in the side bestowed by the unseen and
unaccountable old joker. That odd sort of wayward mood I am speaking of, comes
over a man only in some time of extreme tribulation; it comes in the very midst
of his earnestness, so that what just before might have seemed to him a thing
most momentous, now seems but a part of the general joke. There is nothing like
the perils of whaling to breed this free and easy sort of genial, desperado
philosophy; and with it I now regarded this whole voyage of the Pequod, and the
great White Whale its object.

“Queequeg,” said I, when they had dragged me, the last man, to the deck, and I
was still shaking myself in my jacket to fling off the water; “Queequeg, my
fine friend, does this sort of thing often happen?” Without much emotion,
though soaked through just like me, he gave me to understand that such things
did often happen.

“Mr. Stubb,” said I, turning to that worthy, who, buttoned up in his
oil-jacket, was now calmly smoking his pipe in the rain; “Mr. Stubb, I think I
have heard you say that of all whalemen you ever met, our chief mate, Mr.
Starbuck, is by far the most careful and prudent. I suppose then, that going
plump on a flying whale with your sail set in a foggy squall is the height of a
whaleman’s discretion?”

“Certain. I’ve lowered for whales from a leaking ship in a gale off Cape Horn.”

“Mr. Flask,” said I, turning to little King-Post, who was standing close by;
“you are experienced in these things, and I am not. Will you tell me whether it
is an unalterable law in this fishery, Mr. Flask, for an oarsman to break his
own back pulling himself back-foremost into death’s jaws?”

“Can’t you twist that smaller?” said Flask. “Yes, that’s the law. I should
like to see a boat’s crew backing water up to a whale face foremost. Ha, ha!
the whale would give them squint for squint, mind that!”

Here then, from three impartial witnesses, I had a deliberate statement of the
entire case. Considering, therefore, that squalls and capsizings in the water
and consequent bivouacks on the deep, were matters of common occurrence in this
kind of life; considering that at the superlatively critical instant of going
on to the whale I must resign my life into the hands of him who steered the
boat--oftentimes a fellow who at that very moment is in his impetuousness upon
the point of scuttling the craft with his own frantic stampings; considering
that the particular disaster to our own particular boat was chiefly to be
imputed to Starbuck’s driving on to his whale almost in the teeth of a squall,
and considering that Starbuck, notwithstanding, was famous for his great
heedfulness in the fishery; considering that I belonged to this uncommonly
prudent Starbuck’s boat; and finally considering in what a devil’s chase I was
implicated, touching the White Whale: taking all things together, I say, I
thought I might as well go below and make a rough draft of my will. “Queequeg,”
said I, “come along, you shall be my lawyer, executor, and legatee.”

It may seem strange that of all men sailors should be tinkering at their last
wills and testaments, but there are no people in the world more fond of that
diversion. This was the fourth time in my nautical life that I had done the
same thing. After the ceremony was concluded upon the present occasion, I felt
all the easier; a stone was rolled away from my heart. Besides, all the days I
should now live would be as good as the days that Lazarus lived after his
resurrection; a supplementary clean gain of so many months or weeks as the case
might be. I survived myself; my death and burial were locked up in my chest. I
looked round me tranquilly and contentedly, like a quiet ghost with a clean
conscience sitting inside the bars of a snug family vault.

Now then, thought I, unconsciously rolling up the sleeves of my frock, here
goes for a cool, collected dive at death and destruction, and the devil fetch
the hindmost.
