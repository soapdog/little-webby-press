### Chapter 33.

# The Specksnyder.

Concerning the officers of the whale-craft, this seems as good a place as any
to set down a little domestic peculiarity on ship-board, arising from the
existence of the harpooneer class of officers, a class unknown of course in any
other marine than the whale-fleet.

The large importance attached to the harpooneer’s vocation is evinced by the
fact, that originally in the old Dutch Fishery, two centuries and more ago, the
command of a whale ship was not wholly lodged in the person now called the
captain, but was divided between him and an officer called the _Specksnyder._
Literally this word means Fat-Cutter; usage, however, in time made it
equivalent to Chief Harpooneer. In those days, the captain’s authority was
restricted to the navigation and general management of the vessel; while over
the whale-hunting department and all its concerns, the Specksnyder or Chief
Harpooneer reigned supreme. In the British Greenland Fishery, under the
corrupted title of Specksioneer, this old Dutch official is still retained, but
his former dignity is sadly abridged. At present he ranks simply as senior
Harpooneer; and as such, is but one of the captain’s more inferior subalterns.
Nevertheless, as upon the good conduct of the harpooneers the success of a
whaling voyage largely depends, and since in the American Fishery he is not
only an important officer in the boat, but under certain circumstances (night
watches on a whaling ground) the command of the ship’s deck is also his;
therefore the grand political maxim of the sea demands, that he should
nominally live apart from the men before the mast, and be in some way
distinguished as their professional superior; though always, by them,
familiarly regarded as their social equal.

Now, the grand distinction drawn between officer and man at sea, is this — the
first lives aft, the last forward. Hence, in whale-ships and merchantmen alike,
the mates have their quarters with the captain; and so, too, in most of the
American whalers the harpooneers are lodged in the after part of the ship. That
is to say, they take their meals in the captain’s cabin, and sleep in a place
indirectly communicating with it.

Though the long period of a Southern whaling voyage (by far the longest of all
voyages now or ever made by man), the peculiar perils of it, and the community
of interest prevailing among a company, all of whom, high or low, depend for
their profits, not upon fixed wages, but upon their common luck, together with
their common vigilance, intrepidity, and hard work; though all these things do
in some cases tend to beget a less rigorous discipline than in merchantmen
generally; yet, never mind how much like an old Mesopotamian family these
whalemen may, in some primitive instances, live together; for all that, the
punctilious externals, at least, of the quarter-deck are seldom materially
relaxed, and in no instance done away. Indeed, many are the Nantucket ships in
which you will see the skipper parading his quarter-deck with an elated
grandeur not surpassed in any military navy; nay, extorting almost as much
outward homage as if he wore the imperial purple, and not the shabbiest of
pilot-cloth.

And though of all men the moody captain of the _Pequod_ was the least given to
that sort of shallowest assumption; and though the only homage he ever exacted,
was implicit, instantaneous obedience; though he required no man to remove the
shoes from his feet ere stepping upon the quarter-deck; and though there were
times when, owing to peculiar circumstances connected with events hereafter to
be detailed, he addressed them in unusual terms, whether of condescension or
_in terrorem,_ or otherwise; yet even Captain Ahab was by no means unobservant
of the paramount forms and usages of the sea.

Nor, perhaps, will it fail to be eventually perceived, that behind those forms
and usages, as it were, he sometimes masked himself; incidentally making use of
them for other and more private ends than they were legitimately intended to
subserve. That certain sultanism of his brain, which had otherwise in a good
degree remained unmanifested; through those forms that same sultanism became
incarnate in an irresistible dictatorship. For be a man’s intellectual
superiority what it will, it can never assume the practical, available
supremacy over other men, without the aid of some sort of external arts and
entrenchments, always, in themselves, more or less paltry and base. This it is,
that for ever keeps God’s true princes of the Empire from the world’s hustings;
and leaves the highest honours that this air can give, to those men who become
famous more through their infinite inferiority to the choice hidden handful of
the Divine Inert, than through their undoubted superiority over the dead level
of the mass. Such large virtue lurks in these small things when extreme
political superstitions invest them, that in some royal instances even to idiot
imbecility they have imparted potency. But when, as in the case of Nicholas the
Czar, the ringed crown of geographical empire encircles an imperial brain;
then, the plebeian herds crouch abased before the tremendous centralization.
Nor, will the tragic dramatist who would depict mortal indomitableness in its
fullest sweep and direct swing, ever forget a hint, incidentally so important
in his art, as the one now alluded to.

But Ahab, my Captain, still moves before me in all his Nantucket grimness and
shagginess; and in this episode touching Emperors and Kings, I must not conceal
that I have only to do with a poor old whale-hunter like him; and, therefore,
all outward majestical trappings and housings are denied me. Oh, Ahab! what
shall be grand in thee, it must needs be plucked at from the skies, and dived
for in the deep, and featured in the unbodied air!
