### Chapter 34.

# The Cabin-Table.

It is noon; and Dough-Boy, the steward, thrusting his pale loaf-of-bread face
from the cabin-scuttle, announces dinner to his lord and master; who, sitting
in the lee quarter-boat, has just been taking an observation of the sun; and is
now mutely reckoning the latitude on the smooth, medallion-shaped tablet,
reserved for that daily purpose on the upper part of his ivory leg. From his
complete inattention to the tidings, you would think that moody Ahab had not
heard his menial. But presently, catching hold of the mizen shrouds, he swings
himself to the deck, and in an even, unexhilarated voice, saying, “Dinner, Mr.
Starbuck,” disappears into the cabin.

When the last echo of his sultan’s step has died away, and Starbuck, the first
Emir, has every reason to suppose that he is seated, then Starbuck rouses from
his quietude, takes a few turns along the planks, and, after a grave peep into
the binnacle, says, with some touch of pleasantness, “Dinner, Mr. Stubb,” and
descends the scuttle. The second Emir lounges about the rigging awhile, and
then slightly shaking the main brace, to see whether it will be all right with
that important rope, he likewise takes up the old burden, and with a rapid
“Dinner, Mr. Flask,” follows after his predecessors.

But the third Emir, now seeing himself all alone on the quarter-deck, seems to
feel relieved from some curious restraint; for, tipping all sorts of knowing
winks in all sorts of directions, and kicking off his shoes, he strikes into a
sharp but noiseless squall of a hornpipe right over the Grand Turk’s head; and
then, by a dexterous sleight, pitching his cap up into the mizentop for a
shelf, he goes down rollicking so far at least as he remains visible from the
deck, reversing all other processions, by bringing up the rear with music. But
ere stepping into the cabin doorway below, he pauses, ships a new face
altogether, and, then, independent, hilarious little Flask enters King Ahab’s
presence, in the character of Abjectus, or the Slave.

It is not the least among the strange things bred by the intense artificialness
of sea-usages, that while in the open air of the deck some officers will, upon
provocation, bear themselves boldly and defyingly enough towards their
commander; yet, ten to one, let those very officers the next moment go down to
their customary dinner in that same commander’s cabin, and straightway their
inoffensive, not to say deprecatory and humble air towards him, as he sits at
the head of the table; this is marvellous, sometimes most comical. Wherefore
this difference? A problem? Perhaps not. To have been Belshazzar, King of
Babylon; and to have been Belshazzar, not haughtily but courteously, therein
certainly must have been some touch of mundane grandeur. But he who in the
rightly regal and intelligent spirit presides over his own private dinner-table
of invited guests, that man’s unchallenged power and dominion of individual
influence for the time; that man’s royalty of state transcends Belshazzar’s,
for Belshazzar was not the greatest. Who has but once dined his friends, has
tasted what it is to be Caesar. It is a witchery of social czarship which there
is no withstanding. Now, if to this consideration you superadd the official
supremacy of a ship-master, then, by inference, you will derive the cause of
that peculiarity of sea-life just mentioned.

Over his ivory-inlaid table, Ahab presided like a mute, maned sea-lion on the
white coral beach, surrounded by his warlike but still deferential cubs. In his
own proper turn, each officer waited to be served. They were as little children
before Ahab; and yet, in Ahab, there seemed not to lurk the smallest social
arrogance. With one mind, their intent eyes all fastened upon the old man’s
knife, as he carved the chief dish before him. I do not suppose that for the
world they would have profaned that moment with the slightest observation, even
upon so neutral a topic as the weather. No! And when reaching out his knife and
fork, between which the slice of beef was locked, Ahab thereby motioned
Starbuck’s plate towards him, the mate received his meat as though receiving
alms; and cut it tenderly; and a little started if, perchance, the knife grazed
against the plate; and chewed it noiselessly; and swallowed it, not without
circumspection. For, like the Coronation banquet at Frankfort, where the German
Emperor profoundly dines with the seven Imperial Electors, so these cabin meals
were somehow solemn meals, eaten in awful silence; and yet at table old Ahab
forbade not conversation; only he himself was dumb. What a relief it was to
choking Stubb, when a rat made a sudden racket in the hold below. And poor
little Flask, he was the youngest son, and little boy of this weary family
party. His were the shinbones of the saline beef; his would have been the
drumsticks. For Flask to have presumed to help himself, this must have seemed
to him tantamount to larceny in the first degree. Had he helped himself at that
table, doubtless, never more would he have been able to hold his head up in
this honest world; nevertheless, strange to say, Ahab never forbade him. And
had Flask helped himself, the chances were Ahab had never so much as noticed
it. Least of all, did Flask presume to help himself to butter. Whether he
thought the owners of the ship denied it to him, on account of its clotting his
clear, sunny complexion; or whether he deemed that, on so long a voyage in such
marketless waters, butter was at a premium, and therefore was not for him, a
subaltern; however it was, Flask, alas! was a butterless man!

Another thing. Flask was the last person down at the dinner, and Flask is the
first man up. Consider! For hereby Flask’s dinner was badly jammed in point of
time. Starbuck and Stubb both had the start of him; and yet they also have the
privilege of lounging in the rear. If Stubb even, who is but a peg higher than
Flask, happens to have but a small appetite, and soon shows symptoms of
concluding his repast, then Flask must bestir himself, he will not get more
than three mouthfuls that day; for it is against holy usage for Stubb to
precede Flask to the deck. Therefore it was that Flask once admitted in
private, that ever since he had arisen to the dignity of an officer, from that
moment he had never known what it was to be otherwise than hungry, more or
less. For what he ate did not so much relieve his hunger, as keep it immortal
in him. Peace and satisfaction, thought Flask, have for ever departed from my
stomach. I am an officer; but, how I wish I could fish a bit of old-fashioned
beef in the forecastle, as I used to when I was before the mast. There’s the
fruits of promotion now; there’s the vanity of glory: there’s the insanity of
life! Besides, if it were so that any mere sailor of the _Pequod_ had a grudge
against Flask in Flask’s official capacity, all that sailor had to do, in order
to obtain ample vengeance, was to go aft at dinner-time, and get a peep at
Flask through the cabin sky-light, sitting silly and dumfoundered before awful
Ahab.

Now, Ahab and his three mates formed what may be called the first table in the
_Pequod’s_ cabin. After their departure, taking place in inverted order to
their arrival, the canvas cloth was cleared, or rather was restored to some
hurried order by the pallid steward. And then the three harpooneers were bidden
to the feast, they being its residuary legatees. They made a sort of temporary
servants’ hall of the high and mighty cabin.

In strange contrast to the hardly tolerable constraint and nameless invisible
domineerings of the captain’s table, was the entire care-free license and ease,
the almost frantic democracy of those inferior fellows the harpooneers. While
their masters, the mates, seemed afraid of the sound of the hinges of their own
jaws, the harpooneers chewed their food with such a relish that there was a
report to it. They dined like lords; they filled their bellies like Indian
ships all day loading with spices. Such portentous appetites had Queequeg and
Tashtego, that to fill out the vacancies made by the previous repast, often the
pale Dough-Boy was fain to bring on a great baron of salt-junk, seemingly
quarried out of the solid ox. And if he were not lively about it, if he did not
go with a nimble hop-skip-and-jump, then Tashtego had an ungentlemanly way of
accelerating him by darting a fork at his back, harpoon-wise. And once Daggoo,
seized with a sudden humor, assisted Dough-Boy’s memory by snatching him up
bodily, and thrusting his head into a great empty wooden trencher, while
Tashtego, knife in hand, began laying out the circle preliminary to scalping
him. He was naturally a very nervous, shuddering sort of little fellow, this
bread-faced steward; the progeny of a bankrupt baker and a hospital nurse. And
what with the standing spectacle of the black terrific Ahab, and the periodical
tumultuous visitations of these three savages, Dough-Boy’s whole life was one
continual lip-quiver. Commonly, after seeing the harpooneers furnished with all
things they demanded, he would escape from their clutches into his little
pantry adjoining, and fearfully peep out at them through the blinds of its
door, till all was over.

It was a sight to see Queequeg seated over against Tashtego, opposing his filed
teeth to the Indian’s: crosswise to them, Daggoo seated on the floor, for a
bench would have brought his hearse-plumed head to the low carlines; at every
motion of his colossal limbs, making the low cabin framework to shake, as when
an African elephant goes passenger in a ship. But for all this, the great negro
was wonderfully abstemious, not to say dainty. It seemed hardly possible that
by such comparatively small mouthfuls he could keep up the vitality diffused
through so broad, baronial, and superb a person. But, doubtless, this noble
savage fed strong and drank deep of the abounding element of air; and through
his dilated nostrils snuffed in the sublime life of the worlds. Not by beef or
by bread, are giants made or nourished. But Queequeg, he had a mortal, barbaric
smack of the lip in eating — an ugly sound enough — so much so, that the
trembling Dough-Boy almost looked to see whether any marks of teeth lurked in
his own lean arms. And when he would hear Tashtego singing out for him to
produce himself, that his bones might be picked, the simple-witted steward all
but shattered the crockery hanging round him in the pantry, by his sudden fits
of the palsy. Nor did the whetstone which the harpooneers carried in their
pockets, for their lances and other weapons; and with which whetstones, at
dinner, they would ostentatiously sharpen their knives; that grating sound did
not at all tend to tranquillize poor Dough-Boy. How could he forget that in his
Island days, Queequeg, for one, must certainly have been guilty of some
murderous, convivial indiscretions. Alas! Dough-Boy! hard fares the white
waiter who waits upon cannibals. Not a napkin should he carry on his arm, but a
buckler. In good time, though, to his great delight, the three salt-sea
warriors would rise and depart; to his credulous, fable-mongering ears, all
their martial bones jingling in them at every step, like Moorish scimetars in
scabbards.

But, though these barbarians dined in the cabin, and nominally lived there;
still, being anything but sedentary in their habits, they were scarcely ever in
it except at mealtimes, and just before sleeping-time, when they passed through
it to their own peculiar quarters.

In this one matter, Ahab seemed no exception to most American whale captains,
who, as a set, rather incline to the opinion that by rights the ship’s cabin
belongs to them; and that it is by courtesy alone that anybody else is, at any
time, permitted there. So that, in real truth, the mates and harpooneers of the
_Pequod_ might more properly be said to have lived out of the cabin than in it.
For when they did enter it, it was something as a street-door enters a house;
turning inwards for a moment, only to be turned out the next; and, as a
permanent thing, residing in the open air. Nor did they lose much hereby; in
the cabin was no companionship; socially, Ahab was inaccessible. Though
nominally included in the census of Christendom, he was still an alien to it.
He lived in the world, as the last of the Grisly Bears lived in settled
Missouri. And as when Spring and Summer had departed, that wild Logan of the
woods, burying himself in the hollow of a tree, lived out the winter there,
sucking his own paws; so, in his inclement, howling old age, Ahab’s soul, shut
up in the caved trunk of his body, there fed upon the sullen paws of its gloom!
