### Chapter 86.

# The Tail.

Other poets have warbled the praises of the soft eye of the antelope, and the
lovely plumage of the bird that never alights; less celestial, I celebrate a
tail.

Reckoning the largest sized Sperm Whale’s tail to begin at that point of the
trunk where it tapers to about the girth of a man, it comprises upon its upper
surface alone, an area of at least fifty square feet. The compact round body of
its root expands into two broad, firm, flat palms or flukes, gradually shoaling
away to less than an inch in thickness. At the crotch or junction, these
flukes slightly overlap, then sideways recede from each other like wings,
leaving a wide vacancy between. In no living thing are the lines of beauty more
exquisitely defined than in the crescentic borders of these flukes. At its
utmost expansion in the full grown whale, the tail will considerably exceed
twenty feet across.

The entire member seems a dense webbed bed of welded sinews; but cut into it,
and you find that three distinct strata compose it: — upper, middle, and lower.
The fibres in the upper and lower layers, are long and horizontal; those of the
middle one, very short, and running crosswise between the outside layers. This
triune structure, as much as anything else, imparts power to the tail. To the
student of old Roman walls, the middle layer will furnish a curious parallel to
the thin course of tiles always alternating with the stone in those wonderful
relics of the antique, and which undoubtedly contribute so much to the great
strength of the masonry.

But as if this vast local power in the tendinous tail were not enough, the
whole bulk of the leviathan is knit over with a warp and woof of muscular
fibres and filaments, which passing on either side the loins and running down
into the flukes, insensibly blend with them, and largely contribute to their
might; so that in the tail the confluent measureless force of the whole whale
seems concentrated to a point. Could annihilation occur to matter, this were
the thing to do it.

Nor does this — its amazing strength, at all tend to cripple the graceful
flexion of its motions; where infantileness of ease undulates through a
Titanism of power. On the contrary, those motions derive their most appalling
beauty from it. Real strength never impairs beauty or harmony, but it often
bestows it; and in everything imposingly beautiful, strength has much to do
with the magic. Take away the tied tendons that all over seem bursting from the
marble in the carved Hercules, and its charm would be gone. As devout Eckerman
lifted the linen sheet from the naked corpse of Goethe, he was overwhelmed with
the massive chest of the man, that seemed as a Roman triumphal arch. When
Angelo paints even God the Father in human form, mark what robustness is there.
And whatever they may reveal of the divine love in the Son, the soft, curled,
hermaphroditical Italian pictures, in which his idea has been most successfully
embodied; these pictures, so destitute as they are of all brawniness, hint
nothing of any power, but the mere negative, feminine one of submission and
endurance, which on all hands it is conceded, form the peculiar practical
virtues of his teachings.

Such is the subtle elasticity of the organ I treat of, that whether wielded in
sport, or in earnest, or in anger, whatever be the mood it be in, its flexions
are invariably marked by exceeding grace. Therein no fairy’s arm can transcend
it.

Five great motions are peculiar to it. First, when used as a fin for
progression; Second, when used as a mace in battle; Third, in sweeping; Fourth,
in lobtailing; Fifth, in peaking flukes.

**First:** Being horizontal in its position, the Leviathan’s tail acts in a
different manner from the tails of all other sea creatures. It never wriggles.
In man or fish, wriggling is a sign of inferiority. To the whale, his tail is
the sole means of propulsion. Scroll-wise coiled forwards beneath the body, and
then rapidly sprung backwards, it is this which gives that singular darting,
leaping motion to the monster when furiously swimming. His side-fins only serve
to steer by.

**Second:** It is a little significant, that while one sperm whale only fights
another sperm whale with his head and jaw, nevertheless, in his conflicts with
man, he chiefly and contemptuously uses his tail. In striking at a boat, he
swiftly curves away his flukes from it, and the blow is only inflicted by the
recoil. If it be made in the unobstructed air, especially if it descend to its
mark, the stroke is then simply irresistible. No ribs of man or boat can
withstand it. Your only salvation lies in eluding it; but if it comes sideways
through the opposing water, then partly owing to the light buoyancy of the
whale boat, and the elasticity of its materials, a cracked rib or a dashed
plank or two, a sort of stitch in the side, is generally the most serious
result. These submerged side blows are so often received in the fishery, that
they are accounted mere child’s play. Some one strips off a frock, and the hole
is stopped.

**Third**: I cannot demonstrate it, but it seems to me, that in the whale the
sense of touch is concentrated in the tail; for in this respect there is a
delicacy in it only equalled by the daintiness of the elephant’s trunk. This
delicacy is chiefly evinced in the action of sweeping, when in maidenly
gentleness the whale with a certain soft slowness moves his immense flukes from
side to side upon the surface of the sea; and if he feel but a sailor’s
whisker, woe to that sailor, whiskers and all. What tenderness there is in that
preliminary touch! Had this tail any prehensile power, I should straightway
bethink me of Darmonodes’ elephant that so frequented the flower-market, and
with low salutations presented nosegays to damsels, and then caressed their
zones. On more accounts than one, a pity it is that the whale does not possess
this prehensile virtue in his tail; for I have heard of yet another elephant,
that when wounded in the fight, curved round his trunk and extracted the dart.

**Fourth:** Stealing unawares upon the whale in the fancied security of the
middle of solitary seas, you find him unbent from the vast corpulence of his
dignity, and kitten-like, he plays on the ocean as if it were a hearth. But
still you see his power in his play. The broad palms of his tail are flirted
high into the air; then smiting the surface, the thunderous concussion resounds
for miles. You would almost think a great gun had been discharged; and if you
noticed the light wreath of vapour from the spiracle at his other extremity,
you would think that that was the smoke from the touch-hole.

**Fifth:** As in the ordinary floating posture of the leviathan the flukes lie
considerably below the level of his back, they are then completely out of sight
beneath the surface; but when he is about to plunge into the deeps, his entire
flukes with at least thirty feet of his body are tossed erect in the air, and
so remain vibrating a moment, till they downwards shoot out of view. Excepting
the sublime _breach_ — somewhere else to be described — this peaking of the
whale’s flukes is perhaps the grandest sight to be seen in all animated nature.
Out of the bottomless profundities the gigantic tail seems spasmodically
snatching at the highest heaven. So in dreams, have I seen majestic Satan
thrusting forth his tormented colossal claw from the flame Baltic of Hell. But
in gazing at such scenes, it is all in all what mood you are in; if in the
Dantean, the devils will occur to you; if in that of Isaiah, the archangels.
Standing at the mast-head of my ship during a sunrise that crimsoned sky and
sea, I once saw a large herd of whales in the east, all heading towards the
sun, and for a moment vibrating in concert with peaked flukes. As it seemed to
me at the time, such a grand embodiment of adoration of the gods was never
beheld, even in Persia, the home of the fire worshippers. As Ptolemy Philopater
testified of the African elephant, I then testified of the whale, pronouncing
him the most devout of all beings. For according to King Juba, the military
elephants of antiquity often hailed the morning with their trunks uplifted in
the profoundest silence.

The chance comparison in this chapter, between the whale and the elephant, so
far as some aspects of the tail of the one and the trunk of the other are
concerned, should not tend to place those two opposite organs on an equality,
much less the creatures to which they respectively belong. For as the mightiest
elephant is but a terrier to Leviathan, so, compared with Leviathan’s tail, his
trunk is but the stalk of a lily. The most direful blow from the elephant’s
trunk were as the playful tap of a fan, compared with the measureless crush and
crash of the sperm whale’s ponderous flukes, which in repeated instances have
one after the other hurled entire boats with all their oars and crews into the
air, very much as an Indian juggler tosses his balls.\*

> \*Though all comparison in the way of general bulk between the whale and the
> elephant is preposterous, inasmuch as in that particular the elephant stands
> in much the same respect to the whale that a dog does to the elephant;
> nevertheless, there are not wanting some points of curious similitude; among
> these is the spout. It is well known that the elephant will often draw up
> water or dust in his trunk, and then elevating it, jet it forth in a stream.

---

The more I consider this mighty tail, the more do I deplore my inability to
express it. At times there are gestures in it, which, though they would well
grace the hand of man, remain wholly inexplicable. In an extensive herd, so
remarkable, occasionally, are these mystic gestures, that I have heard hunters
who have declared them akin to Free-Mason signs and symbols; that the whale,
indeed, by these methods intelligently conversed with the world. Nor are there
wanting other motions of the whale in his general body, full of strangeness,
and unaccountable to his most experienced assailant. Dissect him how I may,
then, I but go skin deep; I know him not, and never will. But if I know not
even the tail of this whale, how understand his head? much more, how comprehend
his face, when face he has none? Thou shalt see my back parts, my tail, he
seems to say, but my face shall not be seen. But I cannot completely make out
his back parts; and hint what he will about his face, I say again he has no
face.
