### Chapter 39.

# First Night Watch.

_Fore-Top._

_[__STUBB__ solus, and mending a brace.]_

---

Ha! ha! ha! ha! hem! clear my throat! — I’ve been thinking over it ever since,
and that ha, ha’s the final consequence. Why so? Because a laugh’s the wisest,
easiest answer to all that’s queer; and come what will, one comfort’s always
left — that unfailing comfort is, it’s all predestinated. I heard not all his
talk with Starbuck; but to my poor eye Starbuck then looked something as I the
other evening felt. Be sure the old Mogul has fixed him, too. I twigged it,
knew it; had had the gift, might readily have prophesied it — for when I
clapped my eye upon his skull I saw it. Well, Stubb, _wise_ Stubb — that’s my
title — well, Stubb, what of it, Stubb? Here’s a carcase. I know not all that
may be coming, but be it what it will, I’ll go to it laughing. Such a waggish
leering as lurks in all your horribles! I feel funny. Fa, la! lirra, skirra!
What’s my juicy little pear at home doing now? Crying its eyes out? — Giving a
party to the last arrived harpooneers, I dare say, gay as a frigate’s pennant,
and so am I — fa, la! lirra, skirra! Oh —

We’ll drink to-night with hearts as light, To love, as gay and fleeting As
bubbles that swim, on the beaker’s brim, And break on the lips while meeting.

A brave stave that — who calls? Mr. Starbuck? Aye, aye, sir — *[Aside]* he’s my
superior, he has his too, if I’m not mistaken. — Aye, aye, sir, just through
with this job — coming.
