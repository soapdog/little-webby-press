### Chapter 43.

# Hark!

“_Hist!_ Did you hear that noise, Cabaco?”

It was the middle-watch; a fair moonlight; the seamen were standing in a
cordon, extending from one of the fresh-water butts in the waist, to the
scuttle-butt near the taffrail. In this manner, they passed the buckets to fill
the scuttle-butt. Standing, for the most part, on the hallowed precincts of the
quarter-deck, they were careful not to speak or rustle their feet. From hand to
hand, the buckets went in the deepest silence, only broken by the occasional
flap of a sail, and the steady hum of the unceasingly advancing keel.

It was in the midst of this repose, that Archy, one of the cordon, whose post
was near the after-hatches, whispered to his neighbor, a Cholo, the words
above.

“Hist! did you hear that noise, Cabaco?”

“Take the bucket, will ye, Archy? what noise d’ye mean?”

“There it is again — under the hatches — don’t you hear it — a cough — it
sounded like a cough.”

“Cough be damned! Pass along that return bucket.”

“There again — there it is! — it sounds like two or three sleepers turning
over, now!”

“Caramba! have done, shipmate, will ye? It’s the three soaked biscuits ye eat
for supper turning over inside of ye — nothing else. Look to the bucket!”

“Say what ye will, shipmate; I’ve sharp ears.”

“Aye, you are the chap, ain’t ye, that heard the hum of the old Quakeress’s
knitting-needles fifty miles at sea from Nantucket; you’re the chap.”

“Grin away; we’ll see what turns up. Hark ye, Cabaco, there is somebody down in
the after-hold that has not yet been seen on deck; and I suspect our old Mogul
knows something of it too. I heard Stubb tell Flask, one morning watch, that
there was something of that sort in the wind.”

“Tish! the bucket!”
