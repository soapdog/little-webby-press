### Chapter 55.

# Of the Monstrous Pictures of Whales.

I shall ere long paint to you as well as one can without canvas, something like
the true form of the whale as he actually appears to the eye of the whaleman
when in his own absolute body the whale is moored alongside the whale-ship so
that he can be fairly stepped upon there. It may be worth while, therefore,
previously to advert to those curious imaginary portraits of him which even
down to the present day confidently challenge the faith of the landsman. It is
time to set the world right in this matter, by proving such pictures of the
whale all wrong.

It may be that the primal source of all those pictorial delusions will be found
among the oldest Hindoo, Egyptian, and Grecian sculptures. For ever since those
inventive but unscrupulous times when on the marble panellings of temples, the
pedestals of statues, and on shields, medallions, cups, and coins, the dolphin
was drawn in scales of chain-armor like Saladin’s, and a helmeted head like St.
George’s; ever since then has something of the same sort of license prevailed,
not only in most popular pictures of the whale, but in many scientific
presentations of him.

Now, by all odds, the most ancient extant portrait anyways purporting to be the
whale’s, is to be found in the famous cavern-pagoda of Elephanta, in India. The
Brahmins maintain that in the almost endless sculptures of that immemorial
pagoda, all the trades and pursuits, every conceivable avocation of man, were
prefigured ages before any of them actually came into being. No wonder then,
that in some sort our noble profession of whaling should have been there
shadowed forth. The Hindoo whale referred to, occurs in a separate department
of the wall, depicting the incarnation of Vishnu in the form of leviathan,
learnedly known as the Matse Avatar. But though this sculpture is half man and
half whale, so as only to give the tail of the latter, yet that small section
of him is all wrong. It looks more like the tapering tail of an anaconda, than
the broad palms of the true whale’s majestic flukes.

But go to the old Galleries, and look now at a great Christian painter’s
portrait of this fish; for he succeeds no better than the antediluvian Hindoo.
It is Guido’s picture of Perseus rescuing Andromeda from the sea-monster or
whale. Where did Guido get the model of such a strange creature as that? Nor
does Hogarth, in painting the same scene in his own “Perseus Descending,” make
out one whit better. The huge corpulence of that Hogarthian monster undulates
on the surface, scarcely drawing one inch of water. It has a sort of howdah on
its back, and its distended tusked mouth into which the billows are rolling,
might be taken for the Traitors’ Gate leading from the Thames by water into the
Tower. Then, there are the Prodromus whales of old Scotch Sibbald, and Jonah’s
whale, as depicted in the prints of old Bibles and the cuts of old primers.
What shall be said of these? As for the book-binder’s whale winding like a
vine-stalk round the stock of a descending anchor — as stamped and gilded on
the backs and title-pages of many books both old and new — that is a very
picturesque but purely fabulous creature, imitated, I take it, from the like
figures on antique vases. Though universally denominated a dolphin, I
nevertheless call this book-binder’s fish an attempt at a whale; because it was
so intended when the device was first introduced. It was introduced by an old
Italian publisher somewhere about the 15th century, during the Revival of
Learning; and in those days, and even down to a comparatively late period,
dolphins were popularly supposed to be a species of the Leviathan.

In the vignettes and other embellishments of some ancient books you will at
times meet with very curious touches at the whale, where all manner of spouts,
jets d’eau, hot springs and cold, Saratoga and Baden-Baden, come bubbling up
from his unexhausted brain. In the title-page of the original edition of the
“Advancement of Learning” you will find some curious whales.

But quitting all these unprofessional attempts, let us glance at those pictures
of leviathan purporting to be sober, scientific delineations, by those who
know. In old Harris’s collection of voyages there are some plates of whales
extracted from a Dutch book of voyages, A.D. 1671, entitled _“A Whaling Voyage
to Spitzbergen in the ship Jonas in the Whale, Peter Peterson of Friesland,
master.”_ In one of those plates the whales, like great rafts of logs, are
represented lying among ice-isles, with white bears running over their living
backs. In another plate, the prodigious blunder is made of representing the
whale with perpendicular flukes.

Then again, there is an imposing quarto, written by one Captain Colnett, a Post
Captain in the English navy, entitled _“A Voyage round Cape Horn into the South
Seas, for the purpose of extending the Spermaceti Whale Fisheries.”_ In this
book is an outline purporting to be a “Picture of a Physeter or Spermaceti
whale, drawn by scale from one killed on the coast of Mexico, August, 1793, and
hoisted on deck.” I doubt not the captain had this veracious picture taken for
the benefit of his marines. To mention but one thing about it, let me say that
it has an eye which applied, according to the accompanying scale, to a full
grown sperm whale, would make the eye of that whale a bow-window some five feet
long. Ah, my gallant captain, why did ye not give us Jonah looking out of that
eye!

Nor are the most conscientious compilations of Natural History for the benefit
of the young and tender, free from the same heinousness of mistake. Look at
that popular work _“Goldsmith’s Animated Nature.”_ In the abridged London
edition of 1807, there are plates of an alleged “whale” and a “narwhale.” I do
not wish to seem inelegant, but this unsightly whale looks much like an
amputated sow; and, as for the narwhale, one glimpse at it is enough to amaze
one, that in this nineteenth century such a hippogriff could be palmed for
genuine upon any intelligent public of schoolboys.

Then, again, in 1825, Bernard Germain, Count de Lacepede, a great naturalist,
published a scientific systemized whale book, wherein are several pictures of
the different species of the Leviathan. All these are not only incorrect, but
the picture of the Mysticetus or Greenland whale (that is to say, the Right
whale), even Scoresby, a long experienced man as touching that species,
declares not to have its counterpart in nature.

But the placing of the cap-sheaf to all this blundering business was reserved
for the scientific Frederick Cuvier, brother to the famous Baron. In 1836, he
published a Natural History of Whales, in which he gives what he calls a
picture of the Sperm Whale. Before showing that picture to any Nantucketer, you
had best provide for your summary retreat from Nantucket. In a word, Frederick
Cuvier’s Sperm Whale is not a Sperm Whale, but a squash. Of course, he never
had the benefit of a whaling voyage (such men seldom have), but whence he
derived that picture, who can tell? Perhaps he got it as his scientific
predecessor in the same field, Desmarest, got one of his authentic abortions;
that is, from a Chinese drawing. And what sort of lively lads with the pencil
those Chinese are, many queer cups and saucers inform us.

As for the sign-painters’ whales seen in the streets hanging over the shops of
oil-dealers, what shall be said of them? They are generally Richard III.
whales, with dromedary humps, and very savage; breakfasting on three or four
sailor tarts, that is whaleboats full of mariners: their deformities
floundering in seas of blood and blue paint.

But these manifold mistakes in depicting the whale are not so very surprising
after all. Consider! Most of the scientific drawings have been taken from the
stranded fish; and these are about as correct as a drawing of a wrecked ship,
with broken back, would correctly represent the noble animal itself in all its
undashed pride of hull and spars. Though elephants have stood for their
full-lengths, the living Leviathan has never yet fairly floated himself for his
portrait. The living whale, in his full majesty and significance, is only to be
seen at sea in unfathomable waters; and afloat the vast bulk of him is out of
sight, like a launched line-of-battle ship; and out of that element it is a
thing eternally impossible for mortal man to hoist him bodily into the air, so
as to preserve all his mighty swells and undulations. And, not to speak of the
highly presumable difference of contour between a young sucking whale and a
full-grown Platonian Leviathan; yet, even in the case of one of those young
sucking whales hoisted to a ship’s deck, such is then the outlandish, eel-like,
limbered, varying shape of him, that his precise expression the devil himself
could not catch.

But it may be fancied, that from the naked skeleton of the stranded whale,
accurate hints may be derived touching his true form. Not at all. For it is
one of the more curious things about this Leviathan, that his skeleton gives
very little idea of his general shape. Though Jeremy Bentham’s skeleton, which
hangs for candelabra in the library of one of his executors, correctly conveys
the idea of a burly-browed utilitarian old gentleman, with all Jeremy’s other
leading personal characteristics; yet nothing of this kind could be inferred
from any leviathan’s articulated bones. In fact, as the great Hunter says, the
mere skeleton of the whale bears the same relation to the fully invested and
padded animal as the insect does to the chrysalis that so roundingly envelopes
it. This peculiarity is strikingly evinced in the head, as in some part of this
book will be incidentally shown. It is also very curiously displayed in the
side fin, the bones of which almost exactly answer to the bones of the human
hand, minus only the thumb. This fin has four regular bone-fingers, the index,
middle, ring, and little finger. But all these are permanently lodged in their
fleshy covering, as the human fingers in an artificial covering. “However
recklessly the whale may sometimes serve us,” said humorous Stubb one day, “he
can never be truly said to handle us without mittens.”

For all these reasons, then, any way you may look at it, you must needs
conclude that the great Leviathan is that one creature in the world which must
remain unpainted to the last. True, one portrait may hit the mark much nearer
than another, but none can hit it with any very considerable degree of
exactness. So there is no earthly way of finding out precisely what the whale
really looks like. And the only mode in which you can derive even a tolerable
idea of his living contour, is by going a whaling yourself; but by so doing,
you run no small risk of being eternally stove and sunk by him. Wherefore, it
seems to me you had best not be too fastidious in your curiosity touching this
Leviathan.
