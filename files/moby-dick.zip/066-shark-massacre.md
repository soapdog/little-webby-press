### Chapter 66.

# The Shark Massacre.

When in the Southern Fishery, a captured Sperm Whale, after long and weary
toil, is brought alongside late at night, it is not, as a general thing at
least, customary to proceed at once to the business of cutting him in. For that
business is an exceedingly laborious one; is not very soon completed; and
requires all hands to set about it. Therefore, the common usage is to take in
all sail; lash the helm a’lee; and then send every one below to his hammock
till daylight, with the reservation that, until that time, anchor-watches shall
be kept; that is, two and two for an hour, each couple, the crew in rotation
shall mount the deck to see that all goes well.

But sometimes, especially upon the Line in the Pacific, this plan will not
answer at all; because such incalculable hosts of sharks gather round the
moored carcase, that were he left so for six hours, say, on a stretch, little
more than the skeleton would be visible by morning. In most other parts of the
ocean, however, where these fish do not so largely abound, their wondrous
voracity can be at times considerably diminished, by vigorously stirring them
up with sharp whaling-spades, a procedure notwithstanding, which, in some
instances, only seems to tickle them into still greater activity. But it was
not thus in the present case with the _Pequod’s_ sharks; though, to be sure,
any man unaccustomed to such sights, to have looked over her side that night,
would have almost thought the whole round sea was one huge cheese, and those
sharks the maggots in it.

Nevertheless, upon Stubb setting the anchor-watch after his supper was
concluded; and when, accordingly, Queequeg and a forecastle seaman came on
deck, no small excitement was created among the sharks; for immediately
suspending the cutting stages over the side, and lowering three lanterns, so
that they cast long gleams of light over the turbid sea, these two mariners,
darting their long whaling-spades, kept up an incessant murdering of the
sharks,\* by striking the keen steel deep into their skulls, seemingly their
only vital part. But in the foamy confusion of their mixed and struggling
hosts, the marksmen could not always hit their mark; and this brought about new
revelations of the incredible ferocity of the foe. They viciously snapped, not
only at each other’s disembowelments, but like flexible bows, bent round, and
bit their own; till those entrails seemed swallowed over and over again by the
same mouth, to be oppositely voided by the gaping wound. Nor was this all. It
was unsafe to meddle with the corpses and ghosts of these creatures. A sort of
generic or Pantheistic vitality seemed to lurk in their very joints and bones,
after what might be called the individual life had departed. Killed and hoisted
on deck for the sake of his skin, one of these sharks almost took poor
Queequeg’s hand off, when he tried to shut down the dead lid of his murderous
jaw.

> \* The whaling-spade used for cutting-in is made of the very best steel; is
> about the bigness of a man’s spread hand; and in general shape, corresponds
> to the garden implement after which it is named; only its sides are perfectly
> flat, and its upper end considerably narrower than the lower. This weapon is
> always kept as sharp as possible; and when being used is occasionally honed,
> just like a razor. In its socket, a stiff pole, from twenty to thirty feet
> long, is inserted for a handle.

“Queequeg no care what god made him shark,” said the savage, agonizingly
lifting his hand up and down; “wedder Fejee god or Nantucket god; but de god
wat made shark must be one dam Ingin.”
