### Chapter 71.

# The Jeroboam’s Story.

Hand in hand, ship and breeze blew on; but the breeze came faster than the
ship, and soon the _Pequod_ began to rock.

By and by, through the glass the stranger’s boats and manned mast-heads proved
her a whale-ship. But as she was so far to windward, and shooting by,
apparently making a passage to some other ground, the _Pequod_ could not hope
to reach her. So the signal was set to see what response would be made.

Here be it said, that like the vessels of military marines, the ships of the
American Whale Fleet have each a private signal; all which signals being
collected in a book with the names of the respective vessels attached, every
captain is provided with it. Thereby, the whale commanders are enabled to
recognise each other upon the ocean, even at considerable distances and with no
small facility.

The _Pequod’s_ signal was at last responded to by the stranger’s setting her
own; which proved the ship to be the _Jeroboam_ of Nantucket. Squaring her
yards, she bore down, ranged abeam under the _Pequod’s_ lee, and lowered a
boat; it soon drew nigh; but, as the side-ladder was being rigged by Starbuck’s
order to accommodate the visiting captain, the stranger in question waved his
hand from his boat’s stern in token of that proceeding being entirely
unnecessary. It turned out that the _Jeroboam_ had a malignant epidemic on
board, and that Mayhew, her captain, was fearful of infecting the _Pequod’s_
company. For, though himself and boat’s crew remained untainted, and though his
ship was half a rifle-shot off, and an incorruptible sea and air rolling and
flowing between; yet conscientiously adhering to the timid quarantine of the
land, he peremptorily refused to come into direct contact with the _Pequod._

But this did by no means prevent all communications. Preserving an interval of
some few yards between itself and the ship, the _Jeroboam’s_ boat by the
occasional use of its oars contrived to keep parallel to the _Pequod,_ as she
heavily forged through the sea (for by this time it blew very fresh), with her
main-topsail aback; though, indeed, at times by the sudden onset of a large
rolling wave, the boat would be pushed some way ahead; but would be soon
skilfully brought to her proper bearings again. Subject to this, and other the
like interruptions now and then, a conversation was sustained between the two
parties; but at intervals not without still another interruption of a very
different sort.

Pulling an oar in the _Jeroboam’s_ boat, was a man of a singular appearance,
even in that wild whaling life where individual notabilities make up all
totalities. He was a small, short, youngish man, sprinkled all over his face
with freckles, and wearing redundant yellow hair. A long-skirted,
cabalistically-cut coat of a faded walnut tinge enveloped him; the overlapping
sleeves of which were rolled up on his wrists. A deep, settled, fanatic
delirium was in his eyes.

So soon as this figure had been first descried, Stubb had exclaimed — “That’s
he! that’s he! — the long-togged scaramouch the Town-Ho’s company told us of!”
Stubb here alluded to a strange story told of the _Jeroboam,_ and a certain man
among her crew, some time previous when the _Pequod_ spoke the Town-Ho.
According to this account and what was subsequently learned, it seemed that the
scaramouch in question had gained a wonderful ascendency over almost everybody
in the _Jeroboam._ His story was this:

---

He had been originally nurtured among the crazy society of Neskyeuna Shakers,
where he had been a great prophet; in their cracked, secret meetings having
several times descended from heaven by the way of a trap-door, announcing the
speedy opening of the seventh vial, which he carried in his vest-pocket; but,
which, instead of containing gunpowder, was supposed to be charged with
laudanum. A strange, apostolic whim having seized him, he had left Neskyeuna
for Nantucket, where, with that cunning peculiar to craziness, he assumed a
steady, common-sense exterior, and offered himself as a green-hand candidate
for the _Jeroboam’s_ whaling voyage. They engaged him; but straightway upon the
ship’s getting out of sight of land, his insanity broke out in a freshet. He
announced himself as the archangel Gabriel, and commanded the captain to jump
overboard. He published his manifesto, whereby he set himself forth as the
deliverer of the isles of the sea and vicar-general of all Oceanica. The
unflinching earnestness with which he declared these things; — the dark, daring
play of his sleepless, excited imagination, and all the preternatural terrors
of real delirium, united to invest this Gabriel in the minds of the majority of
the ignorant crew, with an atmosphere of sacredness. Moreover, they were afraid
of him. As such a man, however, was not of much practical use in the ship,
especially as he refused to work except when he pleased, the incredulous
captain would fain have been rid of him; but apprised that that individual’s
intention was to land him in the first convenient port, the archangel forthwith
opened all his seals and vials — devoting the ship and all hands to
unconditional perdition, in case this intention was carried out. So strongly
did he work upon his disciples among the crew, that at last in a body they went
to the captain and told him if Gabriel was sent from the ship, not a man of
them would remain. He was therefore forced to relinquish his plan. Nor would
they permit Gabriel to be any way maltreated, say or do what he would; so that
it came to pass that Gabriel had the complete freedom of the ship. The
consequence of all this was, that the archangel cared little or nothing for the
captain and mates; and since the epidemic had broken out, he carried a higher
hand than ever; declaring that the plague, as he called it, was at his sole
command; nor should it be stayed but according to his good pleasure. The
sailors, mostly poor devils, cringed, and some of them fawned before him; in
obedience to his instructions, sometimes rendering him personal homage, as to a
god. Such things may seem incredible; but, however wondrous, they are true. Nor
is the history of fanatics half so striking in respect to the measureless
self-deception of the fanatic himself, as his measureless power of deceiving
and bedevilling so many others. But it is time to return to the _Pequod._

---

“I fear not thy epidemic, man,” said Ahab from the bulwarks, to Captain Mayhew,
who stood in the boat’s stern; “come on board.”

But now Gabriel started to his feet.

“Think, think of the fevers, yellow and bilious! Beware of the horrible
plague!”

“Gabriel! Gabriel!” cried Captain Mayhew; “thou must either — “ But that
instant a headlong wave shot the boat far ahead, and its seethings drowned all
speech.

“Hast thou seen the White Whale?” demanded Ahab, when the boat drifted back.

“Think, think of thy whale-boat, stoven and sunk! Beware of the horrible tail!”

“I tell thee again, Gabriel, that — “ But again the boat tore ahead as if
dragged by fiends. Nothing was said for some moments, while a succession of
riotous waves rolled by, which by one of those occasional caprices of the seas
were tumbling, not heaving it. Meantime, the hoisted sperm whale’s head jogged
about very violently, and Gabriel was seen eyeing it with rather more
apprehensiveness than his archangel nature seemed to warrant.

When this interlude was over, Captain Mayhew began a dark story concerning Moby
Dick; not, however, without frequent interruptions from Gabriel, whenever his
name was mentioned, and the crazy sea that seemed leagued with him.

---

It seemed that the _Jeroboam_ had not long left home, when upon speaking a
whale-ship, her people were reliably apprised of the existence of Moby Dick,
and the havoc he had made. Greedily sucking in this intelligence, Gabriel
solemnly warned the captain against attacking the White Whale, in case the
monster should be seen; in his gibbering insanity, pronouncing the White Whale
to be no less a being than the Shaker God incarnated; the Shakers receiving the
Bible. But when, some year or two afterwards, Moby Dick was fairly sighted from
the mast-heads, Macey, the chief mate, burned with ardour to encounter him; and
the captain himself being not unwilling to let him have the opportunity,
despite all the archangel’s denunciations and forewarnings, Macey succeeded in
persuading five men to man his boat. With them he pushed off; and, after much
weary pulling, and many perilous, unsuccessful onsets, he at last succeeded in
getting one iron fast. Meantime, Gabriel, ascending to the main-royal
mast-head, was tossing one arm in frantic gestures, and hurling forth
prophecies of speedy doom to the sacrilegious assailants of his divinity. Now,
while Macey, the mate, was standing up in his boat’s bow, and with all the
reckless energy of his tribe was venting his wild exclamations upon the whale,
and essaying to get a fair chance for his poised lance, lo! a broad white
shadow rose from the sea; by its quick, fanning motion, temporarily taking the
breath out of the bodies of the oarsmen. Next instant, the luckless mate, so
full of furious life, was smitten bodily into the air, and making a long arc in
his descent, fell into the sea at the distance of about fifty yards. Not a chip
of the boat was harmed, nor a hair of any oarsman’s head; but the mate for ever
sank.

It is well to parenthesize here, that of the fatal accidents in the Sperm-Whale
Fishery, this kind is perhaps almost as frequent as any. Sometimes, nothing is
injured but the man who is thus annihilated; oftener the boat’s bow is knocked
off, or the thigh-board, in which the headsman stands, is torn from its place
and accompanies the body. But strangest of all is the circumstance, that in
more instances than one, when the body has been recovered, not a single mark of
violence is discernible; the man being stark dead.

The whole calamity, with the falling form of Macey, was plainly descried from
the ship. Raising a piercing shriek — “The vial! the vial!” Gabriel called off
the terror-stricken crew from the further hunting of the whale. This terrible
event clothed the archangel with added influence; because his credulous
disciples believed that he had specifically fore-announced it, instead of only
making a general prophecy, which any one might have done, and so have chanced
to hit one of many marks in the wide margin allowed. He became a nameless
terror to the ship.

---

Mayhew having concluded his narration, Ahab put such questions to him, that the
stranger captain could not forbear inquiring whether he intended to hunt the
White Whale, if opportunity should offer. To which Ahab answered — “Aye.”
Straightway, then, Gabriel once more started to his feet, glaring upon the old
man, and vehemently exclaimed, with downward pointed finger — “Think, think of
the blasphemer — dead, and down there! — beware of the blasphemer’s end!”

Ahab stolidly turned aside; then said to Mayhew, “Captain, I have just
bethought me of my letter-bag; there is a letter for one of thy officers, if I
mistake not. Starbuck, look over the bag.”

Every whale-ship takes out a goodly number of letters for various ships, whose
delivery to the persons to whom they may be addressed, depends upon the mere
chance of encountering them in the four oceans. Thus, most letters never reach
their mark; and many are only received after attaining an age of two or three
years or more.

Soon Starbuck returned with a letter in his hand. It was sorely tumbled, damp,
and covered with a dull, spotted, green mould, in consequence of being kept in
a dark locker of the cabin. Of such a letter, Death himself might well have
been the post-boy.

“Can’st not read it?” cried Ahab. “Give it me, man. Aye, aye, it’s but a dim
scrawl; — what’s this?” As he was studying it out, Starbuck took a long
cutting-spade pole, and with his knife slightly split the end, to insert the
letter there, and in that way, hand it to the boat, without its coming any
closer to the ship.

Meantime, Ahab holding the letter, muttered, “Mr. Har — yes, Mr. Harry — (a
woman’s pinny hand, — the man’s wife, I’ll wager) — Aye — Mr. Harry Macey,
Ship _Jeroboam;_ — why it’s Macey, and he’s dead!”

“Poor fellow! poor fellow! and from his wife,” sighed Mayhew; “but let me have
it.”

“Nay, keep it thyself,” cried Gabriel to Ahab; “thou art soon going that way.”

“Curses throttle thee!” yelled Ahab. “Captain Mayhew, stand by now to receive
it"; and taking the fatal missive from Starbuck’s hands, he caught it in the
slit of the pole, and reached it over towards the boat. But as he did so, the
oarsmen expectantly desisted from rowing; the boat drifted a little towards the
ship’s stern; so that, as if by magic, the letter suddenly ranged along with
Gabriel’s eager hand. He clutched it in an instant, seized the boat-knife, and
impaling the letter on it, sent it thus loaded back into the ship. It fell at
Ahab’s feet. Then Gabriel shrieked out to his comrades to give way with their
oars, and in that manner the mutinous boat rapidly shot away from the _Pequod._

As, after this interlude, the seamen resumed their work upon the jacket of the
whale, many strange things were hinted in reference to this wild affair.
