### Chapter 74.

# The Sperm Whale’s Head — Contrasted View.

Here, now, are two great whales, laying their heads together; let us join them,
and lay together our own.

Of the grand order of folio leviathans, the Sperm Whale and the Right Whale are
by far the most noteworthy. They are the only whales regularly hunted by man.
To the Nantucketer, they present the two extremes of all the known varieties of
the whale. As the external difference between them is mainly observable in
their heads; and as a head of each is this moment hanging from the Pequod’s
side; and as we may freely go from one to the other, by merely stepping across
the deck: — where, I should like to know, will you obtain a better chance to
study practical cetology than here?

In the first place, you are struck by the general contrast between these heads.
Both are massive enough in all conscience; but there is a certain mathematical
symmetry in the Sperm Whale’s which the Right Whale’s sadly lacks. There is
more character in the Sperm Whale’s head. As you behold it, you involuntarily
yield the immense superiority to him, in point of pervading dignity. In the
present instance, too, this dignity is heightened by the pepper and salt colour
of his head at the summit, giving token of advanced age and large experience.
In short, he is what the fishermen technically call a “grey-headed whale."

Let us now note what is least dissimilar in these heads — namely, the two most
important organs, the eye and the ear. Far back on the side of the head, and
low down, near the angle of either whale’s jaw, if you narrowly search, you
will at last see a lashless eye, which you would fancy to be a young colt’s
eye; so out of all proportion is it to the magnitude of the head.

Now, from this peculiar sideway position of the whale’s eyes, it is plain that
he can never see an object which is exactly ahead, no more than he can one
exactly astern. In a word, the position of the whale’s eyes corresponds to that
of a man’s ears; and you may fancy, for yourself, how it would fare with you,
did you sideways survey objects through your ears. You would find that you
could only command some thirty degrees of vision in advance of the straight
side-line of sight; and about thirty more behind it. If your bitterest foe were
walking straight towards you, with dagger uplifted in broad day, you would not
be able to see him, any more than if he were stealing upon you from behind. In
a word, you would have two backs, so to speak; but, at the same time, also, two
fronts (side fronts): for what is it that makes the front of a man — what,
indeed, but his eyes?

Moreover, while in most other animals that I can now think of, the eyes are so
planted as imperceptibly to blend their visual power, so as to produce one
picture and not two to the brain; the peculiar position of the whale’s eyes,
effectually divided as they are by many cubic feet of solid head, which towers
between them like a great mountain separating two lakes in valleys; this, of
course, must wholly separate the impressions which each independent organ
imparts. The whale, therefore, must see one distinct picture on this side, and
another distinct picture on that side; while all between must be profound
darkness and nothingness to him. Man may, in effect, be said to look out on the
world from a sentry-box with two joined sashes for his window. But with the
whale, these two sashes are separately inserted, making two distinct windows,
but sadly impairing the view. This peculiarity of the whale’s eyes is a thing
always to be borne in mind in the fishery; and to be remembered by the reader
in some subsequent scenes.

A curious and most puzzling question might be started concerning this visual
matter as touching the Leviathan. But I must be content with a hint. So long as
a man’s eyes are open in the light, the act of seeing is involuntary; that is,
he cannot then help mechanically seeing whatever objects are before him.
Nevertheless, any one’s experience will teach him, that though he can take in
an undiscriminating sweep of things at one glance, it is quite impossible for
him, attentively, and completely, to examine any two things — however large or
however small — at one and the same instant of time; never mind if they lie
side by side and touch each other. But if you now come to separate these two
objects, and surround each by a circle of profound darkness; then, in order to
see one of them, in such a manner as to bring your mind to bear on it, the
other will be utterly excluded from your contemporary consciousness. How is it,
then, with the whale? True, both his eyes, in themselves, must simultaneously
act; but is his brain so much more comprehensive, combining, and subtle than
man’s, that he can at the same moment of time attentively examine two distinct
prospects, one on one side of him, and the other in an exactly opposite
direction? If he can, then is it as marvellous a thing in him, as if a man were
able simultaneously to go through the demonstrations of two distinct problems
in Euclid. Nor, strictly investigated, is there any incongruity in this
comparison.

It may be but an idle whim, but it has always seemed to me, that the
extraordinary vacillations of movement displayed by some whales when beset by
three or four boats; the timidity and liability to queer frights, so common to
such whales; I think that all this indirectly proceeds from the helpless
perplexity of volition, in which their divided and diametrically opposite
powers of vision must involve them.

But the ear of the whale is full as curious as the eye. If you are an entire
stranger to their race, you might hunt over these two heads for hours, and
never discover that organ. The ear has no external leaf whatever; and into the
hole itself you can hardly insert a quill, so wondrously minute is it. It is
lodged a little behind the eye. With respect to their ears, this important
difference is to be observed between the sperm whale and the right. While the
ear of the former has an external opening, that of the latter is entirely and
evenly covered over with a membrane, so as to be quite imperceptible from
without.

Is it not curious, that so vast a being as the whale should see the world
through so small an eye, and hear the thunder through an ear which is smaller
than a hare’s? But if his eyes were broad as the lens of Herschel’s great
telescope; and his ears capacious as the porches of cathedrals; would that make
him any longer of sight, or sharper of hearing? Not at all. — Why then do you
try to “enlarge” your mind? Subtilize it.

Let us now with whatever levers and steam-engines we have at hand, cant over
the sperm whale’s head, that it may lie bottom up; then, ascending by a ladder
to the summit, have a peep down the mouth; and were it not that the body is now
completely separated from it, with a lantern we might descend into the great
Kentucky Mammoth Cave of his stomach. But let us hold on here by this tooth,
and look about us where we are. What a really beautiful and chaste-looking
mouth! from floor to ceiling, lined, or rather papered with a glistening white
membrane, glossy as bridal satins.

But come out now, and look at this portentous lower jaw, which seems like the
long narrow lid of an immense snuff-box, with the hinge at one end, instead of
one side. If you pry it up, so as to get it overhead, and expose its rows of
teeth, it seems a terrific portcullis; and such, alas! it proves to many a poor
wight in the fishery, upon whom these spikes fall with impaling force. But far
more terrible is it to behold, when fathoms down in the sea, you see some sulky
whale, floating there suspended, with his prodigious jaw, some fifteen feet
long, hanging straight down at right-angles with his body, for all the world
like a ship’s jib-boom. This whale is not dead; he is only dispirited; out of
sorts, perhaps; hypochondriac; and so supine, that the hinges of his jaw have
relaxed, leaving him there in that ungainly sort of plight, a reproach to all
his tribe, who must, no doubt, imprecate lock-jaws upon him.

In most cases this lower jaw — being easily unhinged by a practised artist — is
disengaged and hoisted on deck for the purpose of extracting the ivory teeth,
and furnishing a supply of that hard white whalebone with which the fishermen
fashion all sorts of curious articles, including canes, umbrella-stocks, and
handles to riding-whips.

With a long, weary hoist the jaw is dragged on board, as if it were an anchor;
and when the proper time comes — some few days after the other work — Queequeg,
Daggoo, and Tashtego, being all accomplished dentists, are set to drawing
teeth. With a keen cutting-spade, Queequeg lances the gums; then the jaw is
lashed down to ringbolts, and a tackle being rigged from aloft, they drag out
these teeth, as Michigan oxen drag stumps of old oaks out of wild wood lands.
There are generally forty-two teeth in all; in old whales, much worn down, but
undecayed; nor filled after our artificial fashion. The jaw is afterwards sawn
into slabs, and piled away like joists for building houses.
