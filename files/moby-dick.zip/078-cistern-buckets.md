### Chapter 78.

# Cistern and Buckets.

Nimble as a cat, Tashtego mounts aloft; and without altering his erect posture,
runs straight out upon the overhanging mainyard-arm, to the part where it
exactly projects over the hoisted Tun. He has carried with him a light tackle
called a whip, consisting of only two parts, travelling through a
single-sheaved block. Securing this block, so that it hangs down from the
yard-arm, he swings one end of the rope, till it is caught and firmly held by a
hand on deck. Then, hand-over-hand, down the other part, the Indian drops
through the air, till dexterously he lands on the summit of the head. There —
still high elevated above the rest of the company, to whom he vivaciously cries
— he seems some Turkish Muezzin calling the good people to prayers from the top
of a tower. A short-handled sharp spade being sent up to him, he diligently
searches for the proper place to begin breaking into the Tun. In this business
he proceeds very heedfully, like a treasure-hunter in some old house, sounding
the walls to find where the gold is masoned in. By the time this cautious
search is over, a stout iron-bound bucket, precisely like a well-bucket, has
been attached to one end of the whip; while the other end, being stretched
across the deck, is there held by two or three alert hands. These last now
hoist the bucket within grasp of the Indian, to whom another person has reached
up a very long pole. Inserting this pole into the bucket, Tashtego downward
guides the bucket into the Tun, till it entirely disappears; then giving the
word to the seamen at the whip, up comes the bucket again, all bubbling like a
dairy-maid’s pail of new milk. Carefully lowered from its height, the
full-freighted vessel is caught by an appointed hand, and quickly emptied into
a large tub. Then remounting aloft, it again goes through the same round until
the deep cistern will yield no more. Towards the end, Tashtego has to ram his
long pole harder and harder, and deeper and deeper into the Tun, until some
twenty feet of the pole have gone down.

Now, the people of the _Pequod_ had been baling some time in this way; several
tubs had been filled with the fragrant sperm; when all at once a queer accident
happened. Whether it was that Tashtego, that wild Indian, was so heedless and
reckless as to let go for a moment his one-handed hold on the great cabled
tackles suspending the head; or whether the place where he stood was so
treacherous and oozy; or whether the Evil One himself would have it to fall out
so, without stating his particular reasons; how it was exactly, there is no
telling now; but, on a sudden, as the eightieth or ninetieth bucket came
suckingly up — my God! poor Tashtego — like the twin reciprocating bucket in a
veritable well, dropped head-foremost down into this great Tun of Heidelburgh,
and with a horrible oily gurgling, went clean out of sight!

“Man overboard!” cried Daggoo, who amid the general consternation first came to
his senses. “Swing the bucket this way!” and putting one foot into it, so as
the better to secure his slippery hand-hold on the whip itself, the hoisters
ran him high up to the top of the head, almost before Tashtego could have
reached its interior bottom. Meantime, there was a terrible tumult. Looking
over the side, they saw the before lifeless head throbbing and heaving just
below the surface of the sea, as if that moment seized with some momentous
idea; whereas it was only the poor Indian unconsciously revealing by those
struggles the perilous depth to which he had sunk.

At this instant, while Daggoo, on the summit of the head, was clearing the whip
— which had somehow got foul of the great cutting tackles — a sharp cracking
noise was heard; and to the unspeakable horror of all, one of the two enormous
hooks suspending the head tore out, and with a vast vibration the enormous mass
sideways swung, till the drunk ship reeled and shook as if smitten by an
iceberg. The one remaining hook, upon which the entire strain now depended,
seemed every instant to be on the point of giving way; an event still more
likely from the violent motions of the head.

“Come down, come down!” yelled the seamen to Daggoo, but with one hand holding
on to the heavy tackles, so that if the head should drop, he would still remain
suspended; the negro having cleared the foul line, rammed down the bucket into
the now collapsed well, meaning that the buried harpooneer should grasp it, and
so be hoisted out.

“In heaven’s name, man,” cried Stubb, “are you ramming home a cartridge there?
— Avast! How will that help him; jamming that iron-bound bucket on top of his
head? Avast, will ye!”

“Stand clear of the tackle!” cried a voice like the bursting of a rocket.

Almost in the same instant, with a thunder-boom, the enormous mass dropped into
the sea, like Niagara’s Table-Rock into the whirlpool; the suddenly relieved
hull rolled away from it, to far down her glittering copper; and all caught
their breath, as half swinging — now over the sailors’ heads, and now over the
water — Daggoo, through a thick mist of spray, was dimly beheld clinging to the
pendulous tackles, while poor, buried-alive Tashtego was sinking utterly down
to the bottom of the sea! But hardly had the blinding vapour cleared away,
when a naked figure with a boarding-sword in his hand, was for one swift moment
seen hovering over the bulwarks. The next, a loud splash announced that my
brave Queequeg had dived to the rescue. One packed rush was made to the side,
and every eye counted every ripple, as moment followed moment, and no sign of
either the sinker or the diver could be seen. Some hands now jumped into a boat
alongside, and pushed a little off from the ship.

“Ha! ha!” cried Daggoo, all at once, from his now quiet, swinging perch
overhead; and looking further off from the side, we saw an arm thrust upright
from the blue waves; a sight strange to see, as an arm thrust forth from the
grass over a grave.

“Both! both! — it is both!” — cried Daggoo again with a joyful shout; and soon
after, Queequeg was seen boldly striking out with one hand, and with the other
clutching the long hair of the Indian. Drawn into the waiting boat, they were
quickly brought to the deck; but Tashtego was long in coming to, and Queequeg
did not look very brisk.

Now, how had this noble rescue been accomplished? Why, diving after the slowly
descending head, Queequeg with his keen sword had made side lunges near its
bottom, so as to scuttle a large hole there; then dropping his sword, had
thrust his long arm far inwards and upwards, and so hauled out poor Tash by the
head. He averred, that upon first thrusting in for him, a leg was presented;
but well knowing that that was not as it ought to be, and might occasion great
trouble; — he had thrust back the leg, and by a dexterous heave and toss, had
wrought a somerset upon the Indian; so that with the next trial, he came forth
in the good old way — head foremost. As for the great head itself, that was
doing as well as could be expected.

And thus, through the courage and great skill in obstetrics of Queequeg, the
deliverance, or rather, delivery of Tashtego, was successfully accomplished, in
the teeth, too, of the most untoward and apparently hopeless impediments; which
is a lesson by no means to be forgotten. Midwifery should be taught in the
same course with fencing and boxing, riding and rowing.

I know that this queer adventure of the Gay-Header’s will be sure to seem
incredible to some landsmen, though they themselves may have either seen or
heard of some one’s falling into a cistern ashore; an accident which not seldom
happens, and with much less reason too than the Indian’s, considering the
exceeding slipperiness of the curb of the Sperm Whale’s well.

But, peradventure, it may be sagaciously urged, how is this? We thought the
tissued, infiltrated head of the Sperm Whale, was the lightest and most corky
part about him; and yet thou makest it sink in an element of a far greater
specific gravity than itself. We have thee there. Not at all, but I have ye;
for at the time poor Tash fell in, the case had been nearly emptied of its
lighter contents, leaving little but the dense tendinous wall of the well — a
double welded, hammered substance, as I have before said, much heavier than the
sea water, and a lump of which sinks in it like lead almost. But the tendency
to rapid sinking in this substance was in the present instance materially
counteracted by the other parts of the head remaining undetached from it, so
that it sank very slowly and deliberately indeed, affording Queequeg a fair
chance for performing his agile obstetrics on the run, as you may say. Yes, it
was a running delivery, so it was.

Now, had Tashtego perished in that head, it had been a very precious perishing;
smothered in the very whitest and daintiest of fragrant spermaceti; coffined,
hearsed, and tombed in the secret inner chamber and sanctum sanctorum of the
whale. Only one sweeter end can readily be recalled — the delicious death of an
Ohio honey-hunter, who seeking honey in the crotch of a hollow tree, found such
exceeding store of it, that leaning too far over, it sucked him in, so that he
died embalmed. How many, think ye, have likewise fallen into Plato’s honey
head, and sweetly perished there?
