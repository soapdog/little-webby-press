### Chapter 60.

# The Line.

With reference to the whaling scene shortly to be described, as well as for the
better understanding of all similar scenes elsewhere presented, I have here to
speak of the magical, sometimes horrible whale-line.

The line originally used in the fishery was of the best hemp, slightly vapoured
with tar, not impregnated with it, as in the case of ordinary ropes; for while
tar, as ordinarily used, makes the hemp more pliable to the rope-maker, and
also renders the rope itself more convenient to the sailor for common ship use;
yet, not only would the ordinary quantity too much stiffen the whale-line for
the close coiling to which it must be subjected; but as most seamen are
beginning to learn, tar in general by no means adds to the rope’s durability or
strength, however much it may give it compactness and gloss.

Of late years the Manilla rope has in the American fishery almost entirely
superseded hemp as a material for whale-lines; for, though not so durable as
hemp, it is stronger, and far more soft and elastic; and I will add (since
there is an aesthetics in all things), is much more handsome and becoming to
the boat, than hemp. Hemp is a dusky, dark fellow, a sort of Indian; but
Manilla is as a golden-haired Circassian to behold.

The whale-line is only two-thirds of an inch in thickness. At first sight, you
would not think it so strong as it really is. By experiment its one and fifty
yarns will each suspend a weight of one hundred and twenty pounds; so that the
whole rope will bear a strain nearly equal to three tons. In length, the common
sperm whale-line measures something over two hundred fathoms. Towards the stern
of the boat it is spirally coiled away in the tub, not like the worm-pipe of a
still though, but so as to form one round, cheese-shaped mass of densely bedded
“sheaves,” or layers of concentric spiralizations, without any hollow but the
“heart,” or minute vertical tube formed at the axis of the cheese. As the least
tangle or kink in the coiling would, in running out, infallibly take somebody’s
arm, leg, or entire body off, the utmost precaution is used in stowing the line
in its tub. Some harpooneers will consume almost an entire morning in this
business, carrying the line high aloft and then reeving it downwards through a
block towards the tub, so as in the act of coiling to free it from all possible
wrinkles and twists.

In the English boats two tubs are used instead of one; the same line being
continuously coiled in both tubs. There is some advantage in this; because
these twin-tubs being so small they fit more readily into the boat, and do not
strain it so much; whereas, the American tub, nearly three feet in diameter and
of proportionate depth, makes a rather bulky freight for a craft whose planks
are but one half-inch in thickness; for the bottom of the whale-boat is like
critical ice, which will bear up a considerable distributed weight, but not
very much of a concentrated one. When the painted canvas cover is clapped on
the American line-tub, the boat looks as if it were pulling off with a
prodigious great wedding-cake to present to the whales.

Both ends of the line are exposed; the lower end terminating in an eye-splice
or loop coming up from the bottom against the side of the tub, and hanging over
its edge completely disengaged from everything. This arrangement of the lower
end is necessary on two accounts. _First:_ In order to facilitate the fastening
to it of an additional line from a neighboring boat, in case the stricken whale
should sound so deep as to threaten to carry off the entire line originally
attached to the harpoon. In these instances, the whale of course is shifted
like a mug of ale, as it were, from the one boat to the other; though the first
boat always hovers at hand to assist its consort. _Second:_ This arrangement is
indispensable for common safety’s sake; for were the lower end of the line in
any way attached to the boat, and were the whale then to run the line out to
the end almost in a single, smoking minute as he sometimes does, he would not
stop there, for the doomed boat would infallibly be dragged down after him into
the profundity of the sea; and in that case no town-crier would ever find her
again.

Before lowering the boat for the chase, the upper end of the line is taken aft
from the tub, and passing round the loggerhead there, is again carried forward
the entire length of the boat, resting crosswise upon the loom or handle of
every man’s oar, so that it jogs against his wrist in rowing; and also passing
between the men, as they alternately sit at the opposite gunwales, to the
leaded chocks or grooves in the extreme pointed prow of the boat, where a
wooden pin or skewer the size of a common quill, prevents it from slipping out.
From the chocks it hangs in a slight festoon over the bows, and is then passed
inside the boat again; and some ten or twenty fathoms (called box-line) being
coiled upon the box in the bows, it continues its way to the gunwale still a
little further aft, and is then attached to the short-warp — the rope which is
immediately connected with the harpoon; but previous to that connexion, the
short-warp goes through sundry mystifications too tedious to detail.

Thus the whale-line folds the whole boat in its complicated coils, twisting and
writhing around it in almost every direction. All the oarsmen are involved in
its perilous contortions; so that to the timid eye of the landsman, they seem
as Indian jugglers, with the deadliest snakes sportively festooning their
limbs. Nor can any son of mortal woman, for the first time, seat himself amid
those hempen intricacies, and while straining his utmost at the oar, bethink
him that at any unknown instant the harpoon may be darted, and all these
horrible contortions be put in play like ringed lightnings; he cannot be thus
circumstanced without a shudder that makes the very marrow in his bones to
quiver in him like a shaken jelly. Yet habit — strange thing! what cannot habit
accomplish? — Gayer sallies, more merry mirth, better jokes, and brighter
repartees, you never heard over your mahogany, than you will hear over the
half-inch white cedar of the whale-boat, when thus hung in hangman’s nooses;
and, like the six burghers of Calais before King Edward, the six men composing
the crew pull into the jaws of death, with a halter around every neck, as you
may say.

Perhaps a very little thought will now enable you to account for those repeated
whaling disasters — some few of which are casually chronicled — of this man or
that man being taken out of the boat by the line, and lost. For, when the line
is darting out, to be seated then in the boat, is like being seated in the
midst of the manifold whizzings of a steam-engine in full play, when every
flying beam, and shaft, and wheel, is grazing you. It is worse; for you cannot
sit motionless in the heart of these perils, because the boat is rocking like a
cradle, and you are pitched one way and the other, without the slightest
warning; and only by a certain self-adjusting buoyancy and simultaneousness of
volition and action, can you escape being made a Mazeppa of, and run away with
where the all-seeing sun himself could never pierce you out.

_Again:_ as the profound calm which only apparently precedes and prophesies of
the storm, is perhaps more awful than the storm itself; for, indeed, the calm
is but the wrapper and envelope of the storm; and contains it in itself, as the
seemingly harmless rifle holds the fatal powder, and the ball, and the
explosion; so the graceful repose of the line, as it silently serpentines about
the oarsmen before being brought into actual play — this is a thing which
carries more of true terror than any other aspect of this dangerous affair. But
why say more? All men live enveloped in whale-lines. All are born with halters
round their necks; but it is only when caught in the swift, sudden turn of
death, that mortals realize the silent, subtle, ever-present perils of life.
And if you be a philosopher, though seated in the whale-boat, you would not at
heart feel one whit more of terror, than though seated before your evening fire
with a poker, and not a harpoon, by your side.
