### Chapter 47.

# The Mat-Maker.

It was a cloudy, sultry afternoon; the seamen were lazily lounging about the
decks, or vacantly gazing over into the lead-coloured waters. Queequeg and I
were mildly employed weaving what is called a sword-mat, for an additional
lashing to our boat. So still and subdued and yet somehow preluding was all the
scene, and such an incantation of reverie lurked in the air, that each silent
sailor seemed resolved into his own invisible self.

I was the attendant or page of Queequeg, while busy at the mat. As I kept
passing and repassing the filling or woof of marline between the long yarns of
the warp, using my own hand for the shuttle, and as Queequeg, standing
sideways, ever and anon slid his heavy oaken sword between the threads, and
idly looking off upon the water, carelessly and unthinkingly drove home every
yarn: I say so strange a dreaminess did there then reign all over the ship and
all over the sea, only broken by the intermitting dull sound of the sword, that
it seemed as if this were the Loom of Time, and I myself were a shuttle
mechanically weaving and weaving away at the Fates. There lay the fixed threads
of the warp subject to but one single, ever returning, unchanging vibration,
and that vibration merely enough to admit of the crosswise interblending of
other threads with its own. This warp seemed necessity; and here, thought I,
with my own hand I ply my own shuttle and weave my own destiny into these
unalterable threads. Meantime, Queequeg’s impulsive, indifferent sword,
sometimes hitting the woof slantingly, or crookedly, or strongly, or weakly, as
the case might be; and by this difference in the concluding blow producing a
corresponding contrast in the final aspect of the completed fabric; this
savage’s sword, thought I, which thus finally shapes and fashions both warp and
woof; this easy, indifferent sword must be chance — aye, chance, free will, and
necessity — nowise incompatible — all interweavingly working together. The
straight warp of necessity, not to be swerved from its ultimate course — its
every alternating vibration, indeed, only tending to that; free will still free
to ply her shuttle between given threads; and chance, though restrained in its
play within the right lines of necessity, and sideways in its motions directed
by free will, though thus prescribed to by both, chance by turns rules either,
and has the last featuring blow at events.

Thus we were weaving and weaving away when I started at a sound so strange,
long drawn, and musically wild and unearthly, that the ball of free will
dropped from my hand, and I stood gazing up at the clouds whence that voice
dropped like a wing. High aloft in the cross-trees was that mad Gay-Header,
Tashtego. His body was reaching eagerly forward, his hand stretched out like a
wand, and at brief sudden intervals he continued his cries. To be sure the same
sound was that very moment perhaps being heard all over the seas, from hundreds
of whalemen’s look-outs perched as high in the air; but from few of those lungs
could that accustomed old cry have derived such a marvellous cadence as from
Tashtego the Indian’s.

As he stood hovering over you half suspended in air, so wildly and eagerly
peering towards the horizon, you would have thought him some prophet or seer
beholding the shadows of Fate, and by those wild cries announcing their coming.

“There she blows! there! there! there! she blows! she blows!”

“Where-away?”

“On the lee-beam, about two miles off! a school of them!”

Instantly all was commotion.

The Sperm Whale blows as a clock ticks, with the same undeviating and reliable
uniformity. And thereby whalemen distinguish this fish from other tribes of his
genus.

“There go flukes!” was now the cry from Tashtego; and the whales disappeared.

“Quick, steward!” cried Ahab. “Time! time!”

Dough-Boy hurried below, glanced at the watch, and reported the exact minute to
Ahab.

The ship was now kept away from the wind, and she went gently rolling before
it. Tashtego reporting that the whales had gone down heading to leeward, we
confidently looked to see them again directly in advance of our bows. For that
singular craft at times evinced by the Sperm Whale when, sounding with his head
in one direction, he nevertheless, while concealed beneath the surface, mills
round, and swiftly swims off in the opposite quarter — this deceitfulness of
his could not now be in action; for there was no reason to suppose that the
fish seen by Tashtego had been in any way alarmed, or indeed knew at all of our
vicinity. One of the men selected for shipkeepers — that is, those not
appointed to the boats, by this time relieved the Indian at the main-mast head.
The sailors at the fore and mizzen had come down; the line tubs were fixed in
their places; the cranes were thrust out; the mainyard was backed, and the
three boats swung over the sea like three samphire baskets over high cliffs.
Outside of the bulwarks their eager crews with one hand clung to the rail,
while one foot was expectantly poised on the gunwale. So look the long line of
man-of-war’s men about to throw themselves on board an enemy’s ship.

But at this critical instant a sudden exclamation was heard that took every eye
from the whale. With a start all glared at dark Ahab, who was surrounded by
five dusky phantoms that seemed fresh formed out of air.
