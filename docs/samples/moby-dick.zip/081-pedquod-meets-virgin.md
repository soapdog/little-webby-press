### Chapter 81.

# The _Pequod_ Meets The Virgin.

The predestinated day arrived, and we duly met the ship _Jungfrau,_ Derick De
Deer, master, of Bremen.

At one time the greatest whaling people in the world, the Dutch and Germans are
now among the least; but here and there at very wide intervals of latitude and
longitude, you still occasionally meet with their flag in the Pacific.

For some reason, the _Jungfrau_ seemed quite eager to pay her respects. While
yet some distance from the _Pequod,_ she rounded to, and dropping a boat, her
captain was impelled towards us, impatiently standing in the bows instead of
the stern.

“What has he in his hand there?” cried Starbuck, pointing to something wavingly
held by the German. “Impossible! — a lamp-feeder!”

“Not that,” said Stubb, “no, no, it’s a coffee-pot, Mr. Starbuck; he’s coming
off to make us our coffee, is the Yarman; don’t you see that big tin can there
alongside of him? — that’s his boiling water. Oh! he’s all right, is the
Yarman.”

“Go along with you,” cried Flask, “it’s a lamp-feeder and an oil-can. He’s out
of oil, and has come a-begging.”

However curious it may seem for an oil-ship to be borrowing oil on the
whale-ground, and however much it may invertedly contradict the old proverb
about carrying coals to Newcastle, yet sometimes such a thing really happens;
and in the present case Captain Derick De Deer did indubitably conduct a
lamp-feeder as Flask did declare.

As he mounted the deck, Ahab abruptly accosted him, without at all heeding what
he had in his hand; but in his broken lingo, the German soon evinced his
complete ignorance of the White Whale; immediately turning the conversation to
his lamp-feeder and oil can, with some remarks touching his having to turn into
his hammock at night in profound darkness — his last drop of Bremen oil being
gone, and not a single flying-fish yet captured to supply the deficiency;
concluding by hinting that his ship was indeed what in the Fishery is
technically called a _clean_ one (that is, an empty one), well deserving the
name of _Jungfrau_ or the Virgin.

His necessities supplied, Derick departed; but he had not gained his ship’s
side, when whales were almost simultaneously raised from the mast-heads of both
vessels; and so eager for the chase was Derick, that without pausing to put his
oil-can and lamp-feeder aboard, he slewed round his boat and made after the
leviathan lamp-feeders.

Now, the game having risen to leeward, he and the other three German boats that
soon followed him, had considerably the start of the _Pequod’s_ keels. There
were eight whales, an average pod. Aware of their danger, they were going all
abreast with great speed straight before the wind, rubbing their flanks as
closely as so many spans of horses in harness. They left a great, wide wake,
as though continually unrolling a great wide parchment upon the sea.

Full in this rapid wake, and many fathoms in the rear, swam a huge, humped old
bull, which by his comparatively slow progress, as well as by the unusual
yellowish incrustations overgrowing him, seemed afflicted with the jaundice, or
some other infirmity. Whether this whale belonged to the pod in advance, seemed
questionable; for it is not customary for such venerable leviathans to be at
all social. Nevertheless, he stuck to their wake, though indeed their back
water must have retarded him, because the white-bone or swell at his broad
muzzle was a dashed one, like the swell formed when two hostile currents meet.
His spout was short, slow, and laborious; coming forth with a choking sort of
gush, and spending itself in torn shreds, followed by strange subterranean
commotions in him, which seemed to have egress at his other buried extremity,
causing the waters behind him to upbubble.

“Who’s got some paregoric?” said Stubb, “he has the stomach-ache, I’m afraid.
Lord, think of having half an acre of stomach-ache! Adverse winds are holding
mad Christmas in him, boys. It’s the first foul wind I ever knew to blow from
astern; but look, did ever whale yaw so before? it must be, he’s lost his
tiller.”

As an overladen Indiaman bearing down the Hindostan coast with a deck load of
frightened horses, careens, buries, rolls, and wallows on her way; so did this
old whale heave his aged bulk, and now and then partly turning over on his
cumbrous rib-ends, expose the cause of his devious wake in the unnatural stump
of his starboard fin. Whether he had lost that fin in battle, or had been born
without it, it were hard to say.

“Only wait a bit, old chap, and I’ll give ye a sling for that wounded arm,”
cried cruel Flask, pointing to the whale-line near him.

“Mind he don’t sling thee with it,” cried Starbuck. “Give way, or the German
will have him.”

With one intent all the combined rival boats were pointed for this one fish,
because not only was he the largest, and therefore the most valuable whale, but
he was nearest to them, and the other whales were going with such great
velocity, moreover, as almost to defy pursuit for the time. At this juncture
the _Pequod’s_ keels had shot by the three German boats last lowered; but from
the great start he had had, Derick’s boat still led the chase, though every
moment neared by his foreign rivals. The only thing they feared, was, that from
being already so nigh to his mark, he would be enabled to dart his iron before
they could completely overtake and pass him. As for Derick, he seemed quite
confident that this would be the case, and occasionally with a deriding gesture
shook his lamp-feeder at the other boats.

“The ungracious and ungrateful dog!” cried Starbuck; “he mocks and dares me
with the very poor-box I filled for him not five minutes ago!” — then in his
old intense whisper — “Give way, greyhounds! Dog to it!”

“I tell ye what it is, men” — cried Stubb to his crew — “it’s against my
religion to get mad; but I’d like to eat that villainous Yarman — Pull — won’t
ye? Are ye going to let that rascal beat ye? Do ye love brandy? A hogshead of
brandy, then, to the best man. Come, why don’t some of ye burst a blood-vessel?
Who’s that been dropping an anchor overboard — we don’t budge an inch — we’re
becalmed. Halloo, here’s grass growing in the boat’s bottom — and by the Lord,
the mast there’s budding. This won’t do, boys. Look at that Yarman! The short
and long of it is, men, will ye spit fire or not?”

“Oh! see the suds he makes!” cried Flask, dancing up and down — “What a hump —
Oh, **do** pile on the beef — lays like a log! Oh! my lads, **do** spring —
slap-jacks and quahogs for supper, you know, my lads — baked clams and muffins
— oh, **do**, **do**, spring, — he’s a hundred barreller — don’t lose him now —
don’t oh, **don’t!** — see that Yarman — Oh, won’t ye pull for your duff, my
lads — such a sog! such a sogger! Don’t ye love sperm? There goes three
thousand dollars, men! — a bank! — a whole bank! The bank of England! — Oh,
**do**, **do**, **do**! — What’s that Yarman about now?”

At this moment Derick was in the act of pitching his lamp-feeder at the
advancing boats, and also his oil-can; perhaps with the double view of
retarding his rivals’ way, and at the same time economically accelerating his
own by the momentary impetus of the backward toss.

“The unmannerly Dutch dogger!” cried Stubb. “Pull now, men, like fifty thousand
line-of-battle-ship loads of red-haired devils. What d’ye say, Tashtego; are
you the man to snap your spine in two-and-twenty pieces for the honour of old
Gayhead? What d’ye say?”

“I say, pull like god-dam,” — cried the Indian.

Fiercely, but evenly incited by the taunts of the German, the _Pequod’s_ three
boats now began ranging almost abreast; and, so disposed, momentarily neared
him. In that fine, loose, chivalrous attitude of the headsman when drawing near
to his prey, the three mates stood up proudly, occasionally backing the after
oarsman with an exhilarating cry of, “There she slides, now! Hurrah for the
white-ash breeze! Down with the Yarman! Sail over him!”

But so decided an original start had Derick had, that spite of all their
gallantry, he would have proved the victor in this race, had not a righteous
judgment descended upon him in a crab which caught the blade of his midship
oarsman. While this clumsy lubber was striving to free his white-ash, and
while, in consequence, Derick’s boat was nigh to capsizing, and he thundering
away at his men in a mighty rage; — that was a good time for Starbuck, Stubb,
and Flask. With a shout, they took a mortal start forwards, and slantingly
ranged up on the German’s quarter. An instant more, and all four boats were
diagonically in the whale’s immediate wake, while stretching from them, on both
sides, was the foaming swell that he made.

It was a terrific, most pitiable, and maddening sight. The whale was now going
head out, and sending his spout before him in a continual tormented jet; while
his one poor fin beat his side in an agony of fright. Now to this hand, now to
that, he yawed in his faltering flight, and still at every billow that he
broke, he spasmodically sank in the sea, or sideways rolled towards the sky his
one beating fin. So have I seen a bird with clipped wing making affrighted
broken circles in the air, vainly striving to escape the piratical hawks. But
the bird has a voice, and with plaintive cries will make known her fear; but
the fear of this vast dumb brute of the sea, was chained up and enchanted in
him; he had no voice, save that choking respiration through his spiracle, and
this made the sight of him unspeakably pitiable; while still, in his amazing
bulk, portcullis jaw, and omnipotent tail, there was enough to appal the
stoutest man who so pitied.

Seeing now that but a very few moments more would give the _Pequod’s_ boats the
advantage, and rather than be thus foiled of his game, Derick chose to hazard
what to him must have seemed a most unusually long dart, ere the last chance
would for ever escape.

But no sooner did his harpooneer stand up for the stroke, than all three tigers
— Queequeg, Tashtego, Daggoo — instinctively sprang to their feet, and standing
in a diagonal row, simultaneously pointed their barbs; and darted over the head
of the German harpooneer, their three Nantucket irons entered the whale.
Blinding vapours of foam and white-fire! The three boats, in the first fury of
the whale’s headlong rush, bumped the German’s aside with such force, that both
Derick and his baffled harpooneer were spilled out, and sailed over by the
three flying keels.

“Don’t be afraid, my butter-boxes,” cried Stubb, casting a passing glance upon
them as he shot by; “ye’ll be picked up presently — all right — I saw some
sharks astern — St. Bernard’s dogs, you know — relieve distressed travellers.
Hurrah! this is the way to sail now. Every keel a sunbeam! Hurrah! — Here we go
like three tin kettles at the tail of a mad cougar! This puts me in mind of
fastening to an elephant in a tilbury on a plain — makes the wheel-spokes fly,
boys, when you fasten to him that way; and there’s danger of being pitched out
too, when you strike a hill. Hurrah! this is the way a fellow feels when he’s
going to Davy Jones — all a rush down an endless inclined plane! Hurrah! this
whale carries the everlasting mail!”

But the monster’s run was a brief one. Giving a sudden gasp, he tumultuously
sounded. With a grating rush, the three lines flew round the loggerheads with
such a force as to gouge deep grooves in them; while so fearful were the
harpooneers that this rapid sounding would soon exhaust the lines, that using
all their dexterous might, they caught repeated smoking turns with the rope to
hold on; till at last — owing to the perpendicular strain from the lead-lined
chocks of the boats, whence the three ropes went straight down into the blue —
the gunwales of the bows were almost even with the water, while the three
sterns tilted high in the air. And the whale soon ceasing to sound, for some
time they remained in that attitude, fearful of expending more line, though the
position was a little ticklish. But though boats have been taken down and lost
in this way, yet it is this “holding on,” as it is called; this hooking up by
the sharp barbs of his live flesh from the back; this it is that often torments
the Leviathan into soon rising again to meet the sharp lance of his foes. Yet
not to speak of the peril of the thing, it is to be doubted whether this course
is always the best; for it is but reasonable to presume, that the longer the
stricken whale stays under water, the more he is exhausted. Because, owing to
the enormous surface of him — in a full grown sperm whale something less than
2000 square feet — the pressure of the water is immense. We all know what an
astonishing atmospheric weight we ourselves stand up under; even here,
above-ground, in the air; how vast, then, the burden of a whale, bearing on his
back a column of two hundred fathoms of ocean! It must at least equal the
weight of fifty atmospheres. One whaleman has estimated it at the weight of
twenty line-of-battle ships, with all their guns, and stores, and men on board.

As the three boats lay there on that gently rolling sea, gazing down into its
eternal blue noon; and as not a single groan or cry of any sort, nay, not so
much as a ripple or a bubble came up from its depths; what landsman would have
thought, that beneath all that silence and placidity, the utmost monster of the
seas was writhing and wrenching in agony! Not eight inches of perpendicular
rope were visible at the bows. Seems it credible that by three such thin
threads the great Leviathan was suspended like the big weight to an eight day
clock. Suspended? and to what? To three bits of board. Is this the creature of
whom it was once so triumphantly said — “Canst thou fill his skin with barbed
irons? or his head with fish-spears? The sword of him that layeth at him
cannot hold, the spear, the dart, nor the habergeon: he esteemeth iron as
straw; the arrow cannot make him flee; darts are counted as stubble; he
laugheth at the shaking of a spear!” This the creature? this he? Oh! that
unfulfilments should follow the prophets. For with the strength of a thousand
thighs in his tail, Leviathan had run his head under the mountains of the sea,
to hide him from the _Pequod’s_ fish-spears!

In that sloping afternoon sunlight, the shadows that the three boats sent down
beneath the surface, must have been long enough and broad enough to shade half
Xerxes’ army. Who can tell how appalling to the wounded whale must have been
such huge phantoms flitting over his head!

“Stand by, men; he stirs,” cried Starbuck, as the three lines suddenly vibrated
in the water, distinctly conducting upwards to them, as by magnetic wires, the
life and death throbs of the whale, so that every oarsman felt them in his
seat. The next moment, relieved in great part from the downward strain at the
bows, the boats gave a sudden bounce upwards, as a small icefield will, when a
dense herd of white bears are scared from it into the sea.

“Haul in! Haul in!” cried Starbuck again; “he’s rising.”

The lines, of which, hardly an instant before, not one hand’s breadth could
have been gained, were now in long quick coils flung back all dripping into the
boats, and soon the whale broke water within two ship’s lengths of the hunters.

His motions plainly denoted his extreme exhaustion. In most land animals there
are certain valves or flood-gates in many of their veins, whereby when wounded,
the blood is in some degree at least instantly shut off in certain directions.
Not so with the whale; one of whose peculiarities it is to have an entire
non-valvular structure of the blood-vessels, so that when pierced even by so
small a point as a harpoon, a deadly drain is at once begun upon his whole
arterial system; and when this is heightened by the extraordinary pressure of
water at a great distance below the surface, his life may be said to pour from
him in incessant streams. Yet so vast is the quantity of blood in him, and so
distant and numerous its interior fountains, that he will keep thus bleeding
and bleeding for a considerable period; even as in a drought a river will flow,
whose source is in the well-springs of far-off and undiscernible hills. Even
now, when the boats pulled upon this whale, and perilously drew over his
swaying flukes, and the lances were darted into him, they were followed by
steady jets from the new made wound, which kept continually playing, while the
natural spout-hole in his head was only at intervals, however rapid, sending
its affrighted moisture into the air. From this last vent no blood yet came,
because no vital part of him had thus far been struck. His life, as they
significantly call it, was untouched.

As the boats now more closely surrounded him, the whole upper part of his form,
with much of it that is ordinarily submerged, was plainly revealed. His eyes,
or rather the places where his eyes had been, were beheld. As strange misgrown
masses gather in the knot-holes of the noblest oaks when prostrate, so from the
points which the whale’s eyes had once occupied, now protruded blind bulbs,
horribly pitiable to see. But pity there was none. For all his old age, and
his one arm, and his blind eyes, he must die the death and be murdered, in
order to light the gay bridals and other merry-makings of men, and also to
illuminate the solemn churches that preach unconditional inoffensiveness by all
to all. Still rolling in his blood, at last he partially disclosed a strangely
discoloured bunch or protuberance, the size of a bushel, low down on the flank.

“A nice spot,” cried Flask; “just let me prick him there once.”

“Avast!” cried Starbuck, “there’s no need of that!”

But humane Starbuck was too late. At the instant of the dart an ulcerous jet
shot from this cruel wound, and goaded by it into more than sufferable anguish,
the whale now spouting thick blood, with swift fury blindly darted at the
craft, bespattering them and their glorying crews all over with showers of
gore, capsizing Flask’s boat and marring the bows. It was his death stroke.
For, by this time, so spent was he by loss of blood, that he helplessly rolled
away from the wreck he had made; lay panting on his side, impotently flapped
with his stumped fin, then over and over slowly revolved like a waning world;
turned up the white secrets of his belly; lay like a log, and died. It was most
piteous, that last expiring spout. As when by unseen hands the water is
gradually drawn off from some mighty fountain, and with half-stifled melancholy
gurglings the spray-column lowers and lowers to the ground — so the last long
dying spout of the whale.

Soon, while the crews were awaiting the arrival of the ship, the body showed
symptoms of sinking with all its treasures unrifled. Immediately, by Starbuck’s
orders, lines were secured to it at different points, so that ere long every
boat was a buoy; the sunken whale being suspended a few inches beneath them by
the cords. By very heedful management, when the ship drew nigh, the whale was
transferred to her side, and was strongly secured there by the stiffest
fluke-chains, for it was plain that unless artificially upheld, the body would
at once sink to the bottom.

It so chanced that almost upon first cutting into him with the spade, the
entire length of a corroded harpoon was found imbedded in his flesh, on the
lower part of the bunch before described. But as the stumps of harpoons are
frequently found in the dead bodies of captured whales, with the flesh
perfectly healed around them, and no prominence of any kind to denote their
place; therefore, there must needs have been some other unknown reason in the
present case fully to account for the ulceration alluded to. But still more
curious was the fact of a lance-head of stone being found in him, not far from
the buried iron, the flesh perfectly firm about it. Who had darted that stone
lance? And when? It might have been darted by some Nor’ West Indian long before
America was discovered.

What other marvels might have been rummaged out of this monstrous cabinet there
is no telling. But a sudden stop was put to further discoveries, by the ship’s
being unprecedentedly dragged over sideways to the sea, owing to the body’s
immensely increasing tendency to sink. However, Starbuck, who had the ordering
of affairs, hung on to it to the last; hung on to it so resolutely, indeed,
that when at length the ship would have been capsized, if still persisting in
locking arms with the body; then, when the command was given to break clear
from it, such was the immovable strain upon the timber-heads to which the
fluke-chains and cables were fastened, that it was impossible to cast them off.
Meantime everything in the _Pequod_ was aslant. To cross to the other side of
the deck was like walking up the steep gabled roof of a house. The ship groaned
and gasped. Many of the ivory inlayings of her bulwarks and cabins were started
from their places, by the unnatural dislocation. In vain handspikes and crows
were brought to bear upon the immovable fluke-chains, to pry them adrift from
the timberheads; and so low had the whale now settled that the submerged ends
could not be at all approached, while every moment whole tons of ponderosity
seemed added to the sinking bulk, and the ship seemed on the point of going
over.

“Hold on, hold on, won’t ye?” cried Stubb to the body, “don’t be in such a
devil of a hurry to sink! By thunder, men, we must do something or go for it.
No use prying there; avast, I say with your handspikes, and run one of ye for a
prayer book and a pen-knife, and cut the big chains.”

“Knife? Aye, aye,” cried Queequeg, and seizing the carpenter’s heavy hatchet,
he leaned out of a porthole, and steel to iron, began slashing at the largest
fluke-chains. But a few strokes, full of sparks, were given, when the exceeding
strain effected the rest. With a terrific snap, every fastening went adrift;
the ship righted, the carcase sank.

Now, this occasional inevitable sinking of the recently killed Sperm Whale is a
very curious thing; nor has any fisherman yet adequately accounted for it.
Usually the dead Sperm Whale floats with great buoyancy, with its side or belly
considerably elevated above the surface. If the only whales that thus sank were
old, meagre, and broken-hearted creatures, their pads of lard diminished and
all their bones heavy and rheumatic; then you might with some reason assert
that this sinking is caused by an uncommon specific gravity in the fish so
sinking, consequent upon this absence of buoyant matter in him. But it is not
so. For young whales, in the highest health, and swelling with noble
aspirations, prematurely cut off in the warm flush and May of life, with all
their panting lard about them; even these brawny, buoyant heroes do sometimes
sink.

Be it said, however, that the Sperm Whale is far less liable to this accident
than any other species. Where one of that sort go down, twenty Right Whales do.
This difference in the species is no doubt imputable in no small degree to the
greater quantity of bone in the Right Whale; his Venetian blinds alone
sometimes weighing more than a ton; from this incumbrance the Sperm Whale is
wholly free. But there are instances where, after the lapse of many hours or
several days, the sunken whale again rises, more buoyant than in life. But the
reason of this is obvious. Gases are generated in him; he swells to a
prodigious magnitude; becomes a sort of animal balloon. A line-of-battle ship
could hardly keep him under then. In the Shore Whaling, on soundings, among the
Bays of New Zealand, when a Right Whale gives token of sinking, they fasten
buoys to him, with plenty of rope; so that when the body has gone down, they
know where to look for it when it shall have ascended again.

It was not long after the sinking of the body that a cry was heard from the
_Pequod’s_ mast-heads, announcing that the _Jungfrau_ was again lowering her
boats; though the only spout in sight was that of a Fin-Back, belonging to the
species of uncapturable whales, because of its incredible power of swimming.
Nevertheless, the Fin-Back’s spout is so similar to the Sperm Whale’s, that by
unskilful fishermen it is often mistaken for it. And consequently Derick and
all his host were now in valiant chase of this unnearable brute. The Virgin
crowding all sail, made after her four young keels, and thus they all
disappeared far to leeward, still in bold, hopeful chase.

Oh! many are the Fin-Backs, and many are the Dericks, my friend.
