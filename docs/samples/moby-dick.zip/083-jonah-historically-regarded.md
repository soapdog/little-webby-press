### Chapter 83.

# Jonah Historically Regarded.

Reference was made to the historical story of Jonah and the whale in the
preceding chapter. Now some Nantucketers rather distrust this historical story
of Jonah and the whale. But then there were some sceptical Greeks and Romans,
who, standing out from the orthodox pagans of their times, equally doubted the
story of Hercules and the whale, and Arion and the dolphin; and yet their
doubting those traditions did not make those traditions one whit the less
facts, for all that.

One old Sag-Harbor whaleman’s chief reason for questioning the Hebrew story was
this: — He had one of those quaint old-fashioned Bibles, embellished with
curious, unscientific plates; one of which represented Jonah’s whale with two
spouts in his head — a peculiarity only true with respect to a species of the
Leviathan (the Right Whale, and the varieties of that order), concerning which
the fishermen have this saying, “A penny roll would choke him"; his swallow is
so very small. But, to this, Bishop Jebb’s anticipative answer is ready. It is
not necessary, hints the Bishop, that we consider Jonah as tombed in the
whale’s belly, but as temporarily lodged in some part of his mouth. And this
seems reasonable enough in the good Bishop. For truly, the Right Whale’s mouth
would accommodate a couple of whist-tables, and comfortably seat all the
players. Possibly, too, Jonah might have ensconced himself in a hollow tooth;
but, on second thoughts, the Right Whale is toothless.

Another reason which Sag-Harbor (he went by that name) urged for his want of
faith in this matter of the prophet, was something obscurely in reference to
his incarcerated body and the whale’s gastric juices. But this objection
likewise falls to the ground, because a German exegetist supposes that Jonah
must have taken refuge in the floating body of a **dead** whale — even as the
French soldiers in the Russian campaign turned their dead horses into tents,
and crawled into them. Besides, it has been divined by other continental
commentators, that when Jonah was thrown overboard from the Joppa ship, he
straightway effected his escape to another vessel near by, some vessel with a
whale for a figure-head; and, I would add, possibly called _“The Whale,”_ as
some craft are nowadays christened the _“Shark,”_ the _“Gull,”_ the _“Eagle.”_
Nor have there been wanting learned exegetists who have opined that the whale
mentioned in the book of Jonah merely meant a life-preserver — an inflated bag
of wind — which the endangered prophet swam to, and so was saved from a watery
doom. Poor Sag-Harbor, therefore, seems worsted all round. But he had still
another reason for his want of faith. It was this, if I remember right: Jonah
was swallowed by the whale in the Mediterranean Sea, and after three days he
was vomited up somewhere within three days’ journey of Nineveh, a city on the
Tigris, very much more than three days’ journey across from the nearest point
of the Mediterranean coast. How is that?

But was there no other way for the whale to land the prophet within that short
distance of Nineveh? Yes. He might have carried him round by the way of the
Cape of Good Hope. But not to speak of the passage through the whole length of
the Mediterranean, and another passage up the Persian Gulf and Red Sea, such a
supposition would involve the complete circumnavigation of all Africa in three
days, not to speak of the Tigris waters, near the site of Nineveh, being too
shallow for any whale to swim in. Besides, this idea of Jonah’s weathering the
Cape of Good Hope at so early a day would wrest the honour of the discovery of
that great headland from Bartholomew Diaz, its reputed discoverer, and so make
modern history a liar.

But all these foolish arguments of old Sag-Harbor only evinced his foolish
pride of reason — a thing still more reprehensible in him, seeing that he had
but little learning except what he had picked up from the sun and the sea. I
say it only shows his foolish, impious pride, and abominable, devilish
rebellion against the reverend clergy. For by a Portuguese Catholic priest,
this very idea of Jonah’s going to Nineveh via the Cape of Good Hope was
advanced as a signal magnification of the general miracle. And so it was.
Besides, to this day, the highly enlightened Turks devoutly believe in the
historical story of Jonah. And some three centuries ago, an English traveller
in old Harris’s Voyages, speaks of a Turkish Mosque built in honour of Jonah,
in which Mosque was a miraculous lamp that burnt without any oil.
